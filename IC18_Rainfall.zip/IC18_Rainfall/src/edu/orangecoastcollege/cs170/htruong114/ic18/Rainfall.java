package edu.orangecoastcollege.cs170.htruong114.ic18;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;

public class Rainfall {
	public static final int SIZE = 12;
	public static void main(String[] args) 
	{
		double total=0.0, average, min, max;
		
		String[] month = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
		double[] rainfallInches = new double[SIZE];
		
		Scanner consoleScanner = new Scanner(System.in);
		DecimalFormat twoDPs = new DecimalFormat("0.00");
		for(int i = 0; i < month.length; i++)
		{
			System.out.print("Enter rainfall amount (in inches) for " + month[i] + " >> ");
			rainfallInches[i] = consoleScanner.nextDouble();
			total += rainfallInches[i];
		}
		consoleScanner.close();
		
		average = total / SIZE;
		//max and min (sort the array)
		Arrays.sort(rainfallInches);
		min = rainfallInches[0];
		max = rainfallInches[rainfallInches.length -1];
		
		System.out.println("\nTotal Rainfall for the Year (in inches): " + twoDPs.format(total) + "\n"
						+ "Average Rainfall for the Year (in inches): " + twoDPs.format(average) + "\n"
						+ "Minimum Monthly Rainfall (in inches): " + twoDPs.format(min) + "\n"
						+ "Maximim Monthly Rainfall (in inches): " + twoDPs.format(max));

	}

}