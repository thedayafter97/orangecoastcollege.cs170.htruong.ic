package edu.orangecoastcollege.cs170.htruong114.ic25;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class MovieReviews
{

    public static void main(String[] args)
    {
    	DecimalFormat oneDP = new DecimalFormat("0.0");
        ArrayList<Double> reviewsList = new ArrayList<>();
        double review, average, total = 0.0;

        try
        {
            Scanner fileScanner = new Scanner(new File("MovieReview.txt"));
            while(fileScanner.hasNextDouble())
            {
                review = fileScanner.nextDouble();
                total += review;
                reviewsList.add(review);

            }
            fileScanner.close();

            // Print the statistics
            System.out.println("The number of movie reviews is " + reviewsList.size());
            System.out.println("The average review is " + oneDP.format(total / reviewsList.size()));


        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
        }

    }

}
