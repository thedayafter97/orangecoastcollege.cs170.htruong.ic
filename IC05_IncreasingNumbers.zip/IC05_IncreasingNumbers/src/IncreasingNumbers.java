import java.util.Scanner;

public class IncreasingNumbers
{
	public static final int MIN = 0;
	
    public static void main(String[] args)
    {
        int x, y, z, temp;
        Scanner consoleScanner = new Scanner(System.in);
        
        System.out.print("Please enter a non-negative number: ");
        x = consoleScanner.nextInt();
        
        System.out.print("Please enter a non-negative number: ");
        y = consoleScanner.nextInt();
                
        System.out.print("Please enter a non-negative number: ");
        z = consoleScanner.nextInt();
        consoleScanner.close();
        
        if (x >= MIN && y >= MIN && z >= MIN)
        {
        	if ( x > y )
        	{
        		temp = x;
        		x = y;
        		y = temp;
        	}
        	if ( x > z )
        	{
        		temp = x;
        		x = z;
        		z = temp;
        	}
        	if ( y > z )
        	{
        		temp = y;
        		y = z;
        		z = temp;
        	}
        }
        else 
        {
        	System.out.println("\nPlease enter nonnegative numbers only.");
        	System.exit(0);
        }
        System.out.println("\nThe number you entered in increasing order are:\n"
        					+ x + "\n" + y + "\n" + z);     
    }


}
