package edu.orangecoastcollege.cs170.htruong114.ic19;

import java.lang.reflect.Array;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;

public class LATemps
{
    public static final int SIZE = 31;

    public static void main(String[] args)
    {
        int max;
        double average, total = 0.0;

        int[] temps = new int[SIZE];
        DecimalFormat twoDigits = new DecimalFormat("00");
        DecimalFormat oneDP = new DecimalFormat ("0.0");
        Scanner consoleScanner = new Scanner(System.in);
        for (int i = 0; i < temps.length; i++)
        {
            System.out.print("Please enter daily high for October " + twoDigits.format(i+1) + ": ");
            temps[i] = consoleScanner.nextInt();
            total += temps[i];
        }
        consoleScanner.close();

        average = total / temps.length;
        Arrays.sort(temps);
        max = temps[temps.length-1];

        // Create the freqs array
        int[] freqs = new int[max+1];

        // loop through the temps array to keep a count in the freqs array
        // use a for each loop
        // for every single temp in the temps array
        // temp = 78 to begin
        for (int temp : temps)
        {
            freqs[temp]++;
        }
         // After all frequencies have been counted
        int maxFreq = 0;
        int mode = 0;

        for (int i = 0; i < freqs.length-1; i++)
        {
            // If the frequencies at i > maxFreq
            // maxFreq = frequency at i
            if (freqs[i] > maxFreq)
            {
                maxFreq = freqs[i];
                mode = i;
            }
        }
        System.out.println("\n~~~~~~~~~~Temperature Statistics~~~~~~~~~~\n"
                            + "October's highest daily temperature was: " + max
                            + "\nOctober's average high temperature was: " + oneDP.format(average)
                            + "\nOctober's most frequent high temp  was: " + mode);
    }

}
