import java.util.Scanner;
public class JoiningNames
{

    public static void main(String[] args)
    {   
        String first, middle, last;

        Scanner consoleScanner = new Scanner(System.in);
        
        System.out.print("Please enter your first name: ");
        
        first = consoleScanner.nextLine();
        
        System.out.print("Please enter your middle initial: ");
        middle = consoleScanner.nextLine();
        
        System.out.print("Please enter your last name: ");
        last = consoleScanner.nextLine();
        
        System.out.println("\n" + first + " (length = " + first.length() + ")");
        System.out.println(middle + " (length = " + middle.length() + ")");
        System.out.println(last + " (length = " + last.length() + ")");
        
        System.out.println("\n" + last.toUpperCase() + "," + first.toUpperCase() + "," + middle.toUpperCase());
        
        consoleScanner.close();
    }

}
