package edu.orangecoastcollege.cs170.htruong114.ic14;

public class GradeDistributionDemo 
{

	public static void main(String[] args) 
	{
		GradeDistribution course1 = new GradeDistribution(4, 14, 21, 7, 4);
		GradeDistribution course2 = new GradeDistribution(course1);
		
		System.out.println(course1);
		System.out.println(course2);
		if (course1.equals(course2))
		{
			System.out.println("Both Course are the same.");
		}
		else
			System.out.println("The Courses are different.");
        System.out.println();
		
		course2.setAllGrades(5, 7, 10, 15, 20);
		System.out.println(course1);
		System.out.println(course2);
		
		if (course1.equals(course2))
		{
			System.out.println("Both Course are the same.");
		}
		else
			System.out.println("The Courses are different.");
        System.out.println();

	}

}