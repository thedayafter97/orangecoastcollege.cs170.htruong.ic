package edu.orangecoastcollege.cs170.htruong114.ic14;

public class GradeDistribution {

	private int mNumberAs;
	private int mNumberBs;
	private int mNumberCs;
	private int mNumberDs;
	private int mNumberFs;
	private int asteriskCount;

	public GradeDistribution(int numberAs, int numberBs, int numberCs, int numberDs, int numberFs) {
		mNumberAs = numberAs;
		mNumberBs = numberBs;
		mNumberCs = numberCs;
		mNumberDs = numberDs;
		mNumberFs = numberFs;
	}

	public GradeDistribution(GradeDistribution other) {
		mNumberAs = other.mNumberAs;
		mNumberBs = other.mNumberBs;
		mNumberCs = other.mNumberCs;
		mNumberDs = other.mNumberDs;
		mNumberFs = other.mNumberFs;
	}

	public int getNumberOfGrades() {
		
		return (mNumberAs + mNumberBs + mNumberCs + mNumberDs + mNumberFs);
	}

	public int getNumberAs() {
		return mNumberAs;
	}

	public int getNumberBs() {
		return mNumberBs;
	}

	public int getNumberCs() {
		return mNumberCs;
	}

	public int getNumberDs() {
		return mNumberDs;
	}

	public int getNumberFs() {
		return mNumberFs;
	}

	public int getPercentAs() {
		
		return (int) Math.round((mNumberAs / getNumberOfGrades()) * 100);
	}

	public int getPercentBs() {
		
		return (int) Math.round((mNumberBs / getNumberOfGrades()) * 100);
	}

	public int getPercentCs() {
		
		return (int) Math.round((mNumberCs / getNumberOfGrades()) * 100);
	}

	public int getPercentDs() {
		
		return (int) Math.round((mNumberDs / getNumberOfGrades()) * 100);
	}

	public int getPercentFs() {
		 
		return (int) Math.round((mNumberFs / getNumberOfGrades()) * 100);
	}

	public void setAllGrades(int newNumberAs, int newNumberBs, int newNumberCs, int newNumberDs, int newNumberFs) {
		mNumberAs = newNumberAs;
		mNumberBs = newNumberBs;
		mNumberCs = newNumberCs;
		mNumberDs = newNumberDs;
		mNumberFs = newNumberFs;
	}

	public void setNumberAs(int newNumberAs) {
		mNumberAs = newNumberAs;
	}

	public void setNumberBs(int newNumberBs) {
		mNumberBs = newNumberBs;
	}

	public void setNumberCs(int newNumberCs) {
		mNumberCs = newNumberCs;
	}

	public void setNumberDs(int newNumberDs) {
		mNumberDs = newNumberDs;
	}

	public void setNumberFs(int newNumberFs) {
		mNumberFs = newNumberFs;
	}

	public boolean equals(GradeDistribution other) {
		if (mNumberAs == other.mNumberAs && mNumberBs == other.mNumberBs && mNumberCs == other.mNumberCs
				&& mNumberDs == other.mNumberDs && mNumberFs == other.mNumberFs)
			return true;
		else
			return false;
	}

	public String toString() {
		
		for (asteriskCount = 0; asteriskCount < getNumberOfGrades(); asteriskCount++)
		{
			System.out.print("*");
		}
		System.out.println();
		for (asteriskCount = 0; asteriskCount < getNumberAs(); asteriskCount++) 
		{
			System.out.print("*");
		}
		System.out.println(" A");
		
		for (asteriskCount = 0; asteriskCount < getNumberBs(); asteriskCount++) 
		{
			System.out.print("*");
		}
		System.out.println(" B");

		for (asteriskCount = 0; asteriskCount < getNumberCs(); asteriskCount++) 
		{
			System.out.print("*");
		}
		System.out.println(" C");

		for (asteriskCount = 0; asteriskCount < getNumberDs(); asteriskCount++) 
		{
			System.out.print("*");
		}
		System.out.println(" D");

		for (asteriskCount = 0; asteriskCount < getNumberFs(); asteriskCount++) 
		{
			System.out.print("*");
		}
		System.out.println(" F");
		
		String output = mNumberAs + " A's, " + mNumberBs + " B's, " + mNumberCs + " C's, " + mNumberDs + " D's, " + mNumberFs + " F's";
		return output;
	}

}