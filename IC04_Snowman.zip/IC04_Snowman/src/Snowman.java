import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JApplet;
public class Snowman extends JApplet
{
	 public void init()
	 {
	        setSize(300,300);
	 }
	 public void paint (Graphics canvas)
	 {
		 Graphics2D canvas2D = (Graphics2D) canvas;
	     
		 RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
	     canvas2D.setRenderingHints(rh);
	     
		 canvas.fillOval(30, 10, 8, 8);
		 canvas.fillOval(43, 10, 8, 8);
		 canvas.drawArc(32, 23, 18, 8, 170, 200);
		 canvas.drawOval(20, 0, 40, 40);	
		 canvas.drawOval(10, 40, 60, 60);
		 canvas.drawOval(0,100,80,80);
	 }
}
