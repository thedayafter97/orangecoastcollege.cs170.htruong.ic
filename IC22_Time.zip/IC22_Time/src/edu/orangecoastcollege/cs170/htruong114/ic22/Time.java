package edu.orangecoastcollege.cs170.htruong114.ic22;

import java.text.DecimalFormat;

public class Time 
{
	private int mHour;
	private int mMinute;
	private String mMeridiem;
	public Time(int hour, int minute, String meridiem) throws InvalidHourException, InvalidMinuteException, InvalidMeridiemException 
	{
		setHour(hour);
		setMinute(minute);
		setMeridiem(meridiem);
	}
	public int getHour() {
		return mHour;
	}
	public void setHour(int hour) throws InvalidHourException 
	{
		if (hour < 1 || hour > 12)
			throw new InvalidHourException();
		mHour = hour;
	}
	public int getMinute() {
		return mMinute;
	}
	public void setMinute(int minute) throws InvalidMinuteException 
	{
		if (minute < 0 || minute > 59)
			throw new InvalidMinuteException();
		mMinute = minute;
	}
	public String getMeridiem() {
		return mMeridiem;
	}
	public void setMeridiem(String meridiem) throws InvalidMeridiemException 
	{
		if (!meridiem.equalsIgnoreCase("AM") && !meridiem.equalsIgnoreCase("PM"))
			throw new InvalidMeridiemException();
		mMeridiem = meridiem;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mHour;
		result = prime * result + ((mMeridiem == null) ? 0 : mMeridiem.hashCode());
		result = prime * result + mMinute;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Time other = (Time) obj;
		if (mHour != other.mHour)
			return false;
		if (mMeridiem == null) {
			if (other.mMeridiem != null)
				return false;
		} else if (!mMeridiem.equals(other.mMeridiem))
			return false;
		if (mMinute != other.mMinute)
			return false;
		return true;
	}
	
	@Override
	public String toString() 
	{
		DecimalFormat twoDigits = new DecimalFormat("00");
		return twoDigits.format(mHour) + ":" + twoDigits.format(mMinute) + " " + mMeridiem;
	}
	
	

}
