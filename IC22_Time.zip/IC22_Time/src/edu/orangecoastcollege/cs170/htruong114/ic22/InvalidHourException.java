package edu.orangecoastcollege.cs170.htruong114.ic22;

public class InvalidHourException extends Exception
{

	public InvalidHourException()
	{
		// super refers to the constructor in the parent class
		super("The value entered for hour was not an integer in the range 1 to 12.");
	}
	
	public InvalidHourException(String customMessage)
	{
		super(customMessage);
	}
}
