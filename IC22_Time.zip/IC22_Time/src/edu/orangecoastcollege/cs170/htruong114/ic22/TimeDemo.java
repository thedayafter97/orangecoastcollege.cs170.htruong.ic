package edu.orangecoastcollege.cs170.htruong114.ic22;

public class TimeDemo {

	public static void main(String[] args) {
		// Let's make 4 Time objects and print them out
		try 
		{
			Time t1 = new Time(4, 46, "PM");
			System.out.println(t1);
			Time t2 = new Time(13, 46, "PM");
			System.out.println(t2);
			
		} 
		catch (InvalidHourException e) 
		{
			System.out.println(e.getMessage());
		} 
		catch (InvalidMinuteException e) 
		{
			System.out.println(e.getMessage());
		} 
		catch (InvalidMeridiemException e) 
		{
			System.out.println(e.getMessage());
		}

	}

}
