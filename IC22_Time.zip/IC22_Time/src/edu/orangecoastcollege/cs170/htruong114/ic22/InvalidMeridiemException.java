package edu.orangecoastcollege.cs170.htruong114.ic22;

public class InvalidMeridiemException extends Exception
{
	public InvalidMeridiemException()
	{
		// super refers to the constructor in the parent class
		super("The value entered for meridiem was not an format \"AM\" or \"PM\"");
	}
	
	public InvalidMeridiemException(String customMessage)
	{
		super(customMessage);
	}

}
