package edu.orangecoastcollege.cs170.htruong114.ic22;

public class InvalidMinuteException extends Exception
{
	public InvalidMinuteException()
	{
		// super refers to the constructor in the parent class
		super("The value entered for minute was not an integer in the range 1 to 59.");
	}
	
	public InvalidMinuteException(String customMessage)
	{
		super(customMessage);
	}

}
