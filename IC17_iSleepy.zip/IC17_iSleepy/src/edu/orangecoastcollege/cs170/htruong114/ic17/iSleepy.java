package edu.orangecoastcollege.cs170.htruong114.ic17;

import java.text.DecimalFormat;
import java.util.Scanner;

public class iSleepy
{

    public static final int SIZE = 7;

    public static void main(String[] args)
    {
        String[] days = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
        double[] hoursSlept = new double[SIZE];
        double average, total = 0.0;
        // Variables to store rec, app, notRec
        int rec=0, app=0, notRec=0;
        Scanner consoleScanner = new Scanner(System.in);
        DecimalFormat twoDPs = new DecimalFormat("0.00");

        // Let's loop through all 7 days
        for (int i = 0; i < days.length; i++)
        {
            System.out.print("Enter number of hours slept on " + days[i] + ": ");
            hoursSlept[i] = consoleScanner.nextDouble();
            // Determine if hours slept is rec, app, notRec
            if (hoursSlept[i] >= 7 && hoursSlept[i] <= 9)
                rec++;
            if ((hoursSlept[i] == 6)||(hoursSlept[i] >= 10 && hoursSlept[i] <= 11))
                app++;
            if (hoursSlept[i] < 6 || hoursSlept[i] > 11)
                notRec++;

            // Add the hours slept to the total
            total += hoursSlept[i];
        }
        consoleScanner.close();

        average = total / days.length;
        System.out.println();
        System.out.println("Total number of hours slept last week : " + twoDPs.format(total));
        System.out.println("Average number of hours slept per night: " + twoDPs.format(average));

        System.out.println();
        System.out.println("According to the NSF, last week, you sletpt:\n"
                            + rec + " nights of \"recommended\" sleep.\n"
                            + app + " night of \"appropriate\" sleep.\n" // night and nights
                            + notRec + " nights of \"not recommended\" sleep.\n");
        if (average >= 7.0 && average <= 9.0)
        	System.out.println("Overall, your sleep health (on average) is \"Recommended\"");
        else if (average >= 6.0 || average >= 10.0 && average <= 11.0)
        	System.out.println("Overall, your sleep health (on average) is \"May be Appropriate\"");
        else
        	System.out.println("Overall, your sleep health (on average) is \"Not Recommended\"");
    }

}