import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JApplet;

public class OlympicRings extends JApplet
{
    public void init()
    {
        // init sets the size of your canvas;
        setSize(400,200);
    }

    public void paint (Graphics canvas)
    {
        //How to thicken the line
        Graphics2D canvas2D = (Graphics2D) canvas;
        canvas2D.setStroke(new BasicStroke(10));
        
        //anti-aliasing
        RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        canvas2D.setRenderingHints(rh);

        // to change color use canvas.setColor
        canvas.setColor(Color.BLUE);
        canvas.drawOval(10, 10, 100, 100);

        canvas.setColor(Color.YELLOW);
        canvas.drawOval(70, 60, 100, 100);

        canvas.setColor(Color.BLACK);
        canvas.drawOval(130, 10, 100, 100);

        canvas.setColor(Color.GREEN);
        canvas.drawOval(190, 60, 100, 100);

        canvas.setColor(Color.RED);
        canvas.drawOval(250, 10, 100, 100);
    }

}
