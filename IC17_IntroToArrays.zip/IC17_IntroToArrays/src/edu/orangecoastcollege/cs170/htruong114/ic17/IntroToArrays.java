package edu.orangecoastcollege.cs170.htruong114.ic17;

import java.util.Arrays;
import java.util.Scanner;

public class IntroToArrays
{

    public static final int SIZE = 10;

    public static void main(String[] args)
    {

        int[] values = new int[SIZE];
        double average, sum = 0;
        Scanner consoleScanner = new Scanner(System.in);
        for (int i = 0; i < values.length; i++) // Also i < SIZE, i < 10, i <= 9
        {
            System.out.print("Please enter value #" + (i + 1) + ": ");
            values[i] = consoleScanner.nextInt();
            // Add the value to the sum
            sum += values[i];
        }
        consoleScanner.close();
        // Calculate the average AFTER the loop (after all 10 values have been
        // entered)
        average = sum / values.length;

        // sort the array in ascending oreder (smallest to largest)
        Arrays.sort(values);

        System.out.println();
        System.out.println("The largest value in the array is : " + values[values.length - 1]); // Also [9], [SIZE-1]
        System.out.println("The smallest value in the array is : " + values[0]);
        System.out.println("The sum of values in the array is : " + sum);
        System.out.println("The average value in the array is : " + average);
    }
}