import java.text.DecimalFormat;
import java.util.Scanner;

public class BloodAlcoholContent
{
    public static final double OUNCES_ALCOHOL = 1.5;
    public static final double BAC_LIMIT = 0.08;

    public static void main(String[] args)
    {
        double numberOfDrinks, BAC, weights;
        DecimalFormat threeDPs = new DecimalFormat ("0.000");
        Scanner consoleScanner = new Scanner(System.in);
        
        System.out.print("Enter the number of alcohol drinks consumed: ");
        numberOfDrinks = consoleScanner.nextDouble();
        
        System.out.print("Please enter your weight in lbs: ");
        weights = consoleScanner.nextDouble();
        consoleScanner.close();

        BAC = (4.136 * numberOfDrinks * OUNCES_ALCOHOL) / weights;
        System.out.println("\nYour BAC is " + threeDPs.format(BAC));
        
        if (BAC >= BAC_LIMIT)
            System.out.println("According to the state of California, you are intoxicated. Do not drive!");
        else
            System.out.println("According to the state of California, you are still able to drive but BE CAREFUL!");
    }

}
