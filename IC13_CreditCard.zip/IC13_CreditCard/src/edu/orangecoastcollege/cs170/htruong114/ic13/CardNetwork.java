package edu.orangecoastcollege.cs170.htruong114.ic13;

public enum CardNetwork 
{
	AMEX,
	DISCOVER,
	MASTER_CARD,
	VISA;
}