package edu.orangecoastcollege.cs170.htruong114.ic13;

public class CreditCard 
{
	private String mNumber;
	private String mCardHolder;
	private String mExpirationDate;
	private String mSecurityCode;
	private CardNetwork mNetWork;

	public CreditCard(CardNetwork netWork, String number, String cardHolder, String expirationDate, String securityCode) 
	{
		mNetWork=netWork;
		mNumber=number;
		mCardHolder=cardHolder;
		mExpirationDate=expirationDate;
		mSecurityCode=securityCode;
	}

	public String getNumber()
	{
		return mNumber;
	}
	
	public String getCardHolder()
	{
		return mCardHolder;
	}
	
	public String getExpirationDate()
	{
		return mExpirationDate;
	}
	
	public CardNetwork getNetWork()
	{
		return mNetWork;
	}
	
	public String getSecurityCode()
	{
		return mSecurityCode;
	}
	
	public void setCardHolder(String newCardHolder)
	{
		mCardHolder = newCardHolder;
	}
	
	public String toString()
	{
		
		String output = "Credit Card [" + mNetWork + ", " + mNumber.replace(mNumber.substring(0,12), "************") + ", " + mCardHolder + ", " + mExpirationDate + "]";
		return output;
	}
	
	public boolean equals (CreditCard other)
	{
		if (mNetWork.equals(other.mNetWork) && mSecurityCode == other.mSecurityCode && mNumber.equals(other.mNumber) 
				&& mCardHolder.equals(other.mCardHolder) && mExpirationDate.equals(other.mExpirationDate))
				return true;
		else
			return false;
	}
}