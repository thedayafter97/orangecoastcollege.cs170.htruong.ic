package edu.orangecoastcollege.cs170.htruong114.ic13;

import java.util.Scanner;

public class CreditCardDemo 
{

	public static void main(String[] args) 
	{
		String major;
		Scanner consoleScanner = new Scanner(System.in);
		System.out.println("Type consisting of one of the 4 major networks (AMEX, DISCOVER, MASTER_CARD or VISA)");
		major = consoleScanner.nextLine().toUpperCase().replaceAll(" ", "_");
		
		// test enum
		boolean match = false;
		for (CardNetwork network : CardNetwork.values())
        {
            if (major.equals(network.toString()))
            {
                System.out.println("Congratulation on having a new credit card!");
                match = true;
            }
        }
        if (match == false) System.out.println("Sorry we cannot create a new credit card for you!");
		
		// test constructor
		CreditCard person1 = new CreditCard(CardNetwork.VISA, "1234567812345678", "Hoa Truong", "01/2020", "132");
		
		person1.setCardHolder("Nghia Phan");
		System.out.println(person1);
		
		CreditCard person2 = new CreditCard(CardNetwork.MASTER_CARD, "1234567891234567", "Bin Truong", "02/2020", "123");
		System.out.println(person2);
		
		// test equals
		System.out.println("Is Person 1 equal to Person 2? " + person1.equals(person2));
	}

}