package edu.orangecoastcollege.cs170.htruong114.ic23;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Scanner;

public class HabermansSurvival
{

    public static void main(String[] args)
    {
        int minS = Integer.MAX_VALUE, maxS = Integer.MIN_VALUE, minNS = Integer.MAX_VALUE, maxNS = Integer.MIN_VALUE;
        int countS = 0, countNS = 0;
        double averageS, averageNS, sumS = 0.0, sumNS = 0.0;

        // use a Scanner to open file:
        try
        {
            Scanner fileScanner = new Scanner(new File("Haberman.csv"));
            //Let's loop through the file:
            while (fileScanner.hasNextLine())
            {
                // Read a string "30,64,1,1"
                String line = fileScanner.nextLine();
                // Spit method = divides a line into parts (it makes an array of parts)
                // Whenever a "delimeter" character is encountered
                // delimiter = divider
                String[] parts = line.split(",");
                // parts = {"30", " 64", "1", "1"}
                // Extract the parts we need:
                // Use integer.parseInt to convert from String => int
                int nodes = Integer.parseInt(parts[2]);
                int survival = Integer.parseInt(parts[3]);

                // If survival == 1, woman survived over 5 years
                if (survival == 1)
                {
                    countS ++;
                    sumS += nodes;
                    // Determine if it's the min
                    if (nodes < minS)
                        minS = nodes;
                    if (nodes > maxS)
                        maxS = nodes;
                }
                else
                {
                    countNS++;
                    sumNS += nodes;
                    // Determine if it's the min
                    if (nodes < minNS)
                        minNS = nodes;
                    if (nodes > maxNS)
                        maxNS = nodes;
                }

            }
            fileScanner.close();
            averageS = sumS / countS;
            averageNS = sumNS / countNS;
            DecimalFormat twoDGDPs = new DecimalFormat("0.0");
            DecimalFormat oneDG = new DecimalFormat("0");


            System.out.print("Min number of nodes found for a patient who survived beyond 5 years was " + oneDG.format(minS) + "\n"
                    + "Average number of positive axillary nodes detected for patients who survived 5 years or more is " + twoDGDPs.format(averageS) + "\n"
                    + "Max number of nodes found for a patient who survived beyond 5 years was " + oneDG.format(maxS) + "\n"
                    + "\n"
                    + "Min number of nodes found for a patient who did not survived beyond 5 years was " + oneDG.format(minNS) + "\n"
                    + "Average number of positive axillary nodes detected for patients who did not survived 5 years or more is " + twoDGDPs.format(averageNS) + "\n"
                    + "Max number of nodes found for a patient who did not survived beyond 5 years was " + oneDG.format(maxNS));

        }
        catch (IOException e)
        {
            System.out.println("File not found.");
        }


    }

}