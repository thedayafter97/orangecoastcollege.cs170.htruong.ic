import java.text.DecimalFormat;
import java.util.Scanner;
public class BasalMetabolicRate
{

    public static void main(String[] args)
    {
        double weight, height, bmrM, bmrF, age, barsM, barsF;
        
        Scanner consoleScanner = new Scanner(System.in);
        DecimalFormat noDPs = new DecimalFormat("0");
        DecimalFormat oneDP = new DecimalFormat("0.0");
        
        System.out.print("Please enter your weight (lb): ");
        weight = consoleScanner.nextDouble();
        
        System.out.print("Please enter your height (in): ");
        height = consoleScanner.nextDouble();
        
        System.out.print("Please enter your age: ");
        age = consoleScanner.nextDouble();
        
        bmrF = 655 + (4.35 * weight) + (4.7 * height) - (4.7 * age);
        bmrM = 66 + (6.23 * weight) + (12.7 * height) - (6.8 * age);
        
        barsF = bmrF / 230;
        barsM = bmrM / 230;
        
        System.out.println("\nBMR (female): " + noDPs.format(bmrF) + " calories");
        System.out.println("BMR (male): " + noDPs.format(bmrM) + " calories\n");
        System.out.println("If you are female, you need to consume " + oneDP.format(barsF) + " chocolate bars to maintain weight.");
        System.out.print("If you are male, you need to consume " + oneDP.format(barsM) + " chocolate bars to maintain weight.");
        
        consoleScanner.close();
    }

}
