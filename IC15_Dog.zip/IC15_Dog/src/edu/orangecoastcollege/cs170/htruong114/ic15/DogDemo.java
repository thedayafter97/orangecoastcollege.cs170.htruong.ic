package edu.orangecoastcollege.cs170.htruong114.ic15;

public class DogDemo
{

    public static void main(String[] args)
    {
        
        
        Dog scooby = new Dog("Scooby", "Great Dance", 7);
        Dog myDog = new Dog(scooby);
        
        System.out.println(scooby);
        System.out.println(myDog);

        if (scooby.equals(myDog))
            System.out.println("Both dogs are the same.");
        else
            System.out.println("The dogs are different.");
        System.out.println();
        
        myDog.setAge(2);
        myDog.setName("Toby");
        myDog.setBreed("Terrier");
        
        System.out.println(scooby);
        System.out.println(myDog);
        
        if (scooby.equals(myDog))
            System.out.println("Both dogs are the same.");
        else
            System.out.println("The dogs are different.");
    }
}
