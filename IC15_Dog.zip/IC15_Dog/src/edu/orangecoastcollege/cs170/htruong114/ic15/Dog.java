package edu.orangecoastcollege.cs170.htruong114.ic15;

import java.text.DecimalFormat;

public class Dog
{

    DecimalFormat noDPs = new DecimalFormat("0");
    private String mName;
    private String mBreed;
    private int mAge;

    public Dog(String name, String breed, int age)
    {

        mName = name;
        mBreed = breed;
        mAge = age;
    }

    public Dog(Dog other)
    {
        mName = other.mName;
        mBreed = other.mBreed;
        mAge = other.mAge;
    }

    public String getName()
    {
        return mName;
    }

    public void setName(String name)
    {
        mName = name;
    }

    public String getBreed()
    {
        return mBreed;
    }

    public void setBreed(String breed)
    {
        mBreed = breed;
    }

    public int getAge()
    {
        return mAge;
    }

    public void setAge(int age)
    {
        mAge = age;
    }

    public String toString()
    {
        return "Dog [Name=" + mName + ", Breed=" + mBreed + ", Age=" + mAge + ", Human Age=" + noDPs.format(ageInHumanYears()) + "]";
    }

    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + mAge;
        result = prime * result + ((mBreed == null) ? 0 : mBreed.hashCode());
        result = prime * result + ((mName == null) ? 0 : mName.hashCode());
        return result;
    }

    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Dog other = (Dog) obj;
        if (mAge != other.mAge) return false;
        if (mBreed == null)
        {
            if (other.mBreed != null) return false;
        }
        else if (!mBreed.equals(other.mBreed)) return false;
        if (mName == null)
        {
            if (other.mName != null) return false;
        }
        else if (!mName.equals(other.mName)) return false;
        return true;
    }

    public double ageInHumanYears()
    {
        if (mAge <= 2) return mAge * 11;
        else return (mAge - 2) * 5 + 22;
    }

}
