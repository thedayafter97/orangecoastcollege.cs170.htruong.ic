package edu.orangecoastcollege.cs170.htruong114.ic11;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JApplet;

public class OCCLogo extends JApplet
{

    public void init()
    {
        setSize(1050, 960);
    }

    public void paint(Graphics canvas)
    {
        Graphics2D canvas2D = (Graphics2D) canvas;
        canvas2D.setStroke(new BasicStroke(5));
        RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        canvas2D.setRenderingHints(rh);
        // Define custom colors:
        Color occOrange = new Color(245, 146, 59);
        Color occBlue = new Color(0, 80, 161);

        // Let's loop through the x values first:
        for (int x = 0; x < 1050; x += 210)
        {
            for (int y = 0; y <= 960; y += 240)
            {
                canvas.setColor(occOrange);
                canvas.fillOval(x + 10, y + 10, 200, 200);

                canvas.setColor(Color.WHITE);
                canvas.fillOval(x + 20, y + 20, 180, 180);

                canvas.setColor(occBlue);
                canvas.fillArc(x + 25, y + 25, 170, 170, 60, 270);
                canvas.setColor(Color.WHITE);
                canvas.fillOval(x + 42, y + 40, 150, 150);
                canvas.setColor(occBlue);
                canvas.fillArc(x + 45, y + 45, 140, 140, 70, 260);
                canvas.setColor(Color.WHITE);
                canvas.fillOval(x + 62, y + 60, 120, 120);

                // Draw the string "Orange Coast College"
                canvas.setColor(occBlue);
                canvas.drawString("Orange Coast College", x + 50, y + 230);
            }
        }
    }
}