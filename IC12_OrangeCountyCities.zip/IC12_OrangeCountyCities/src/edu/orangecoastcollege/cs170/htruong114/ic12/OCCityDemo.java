package edu.orangecoastcollege.cs170.htruong114.ic12;

import java.util.Scanner;

public class OCCityDemo
{

    public static void main(String[] args)
    {
        String home;
        Scanner consoleScanner = new Scanner(System.in);

        System.out.print("In what city do you live?\n>>");
        home = consoleScanner.nextLine().toUpperCase().replaceAll(" ", "_");

        // Decide whether their home is one of the 34 OC cities
        // Loop through all 34 cities
        // Use a for each loop!
        boolean match = false;

        for (OCCity city : OCCity.values())
        {
            // COSTA_MESA == ALISO_VIEJO
            if (home.equals(city.toString()))
            {
                System.out.println("Hooray! You live in OC!");
                match = true;
            }
        }
        if (match == false) System.out.println("Sorry that you have a cold winter :(");
    }

}