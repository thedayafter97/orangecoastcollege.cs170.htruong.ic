import java.util.Scanner;
public class AverageOfThree
{

    public static void main(String[] args)
    {
        //Declare 4 varible (3 ints, 1 double)
        int number1, number2, number3;
        double average;
        
        // We need something to read input from the user
        // Scanner => reads input from console
        Scanner consoleScanner = new Scanner(System.in);
        
        // Prompt the user for input (int)
        System.out.print("Please enter number 1: ");
        // Read an int value from scanner
        number1 = consoleScanner.nextInt();
        
        System.out.print("Please enter number 2: ");
        number2 = consoleScanner.nextInt();
        
        System.out.print("Please enter number 3: ");
        number3 = consoleScanner.nextInt();
        
        // Calculte the average
        average = (number1 + number2 + number3) / 3;
        
        // Print the average to the console
        System.out.print("The average of the number is: " + average);
        
        // At the end, PLEASE REMEMBER to CLOSE your consoleScanner (stop listening)
        consoleScanner.close();
    }

}
