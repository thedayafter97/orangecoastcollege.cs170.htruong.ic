package edu.orangecoastcollege.cs170.htruong114.ic16;

import java.text.DecimalFormat;

public class Time
{

    private int mHour;
    private int mMinute;

    public Time(int hour, int minute)
    {
        super();
        if (isValid(hour, minute))
        {
            mHour = hour;
            mMinute = minute;
        }
        else
            // IllegalArgumentException means user provided invalid input
            // throw means give it back to user to fix the error
            throw new IllegalArgumentException(
                    "Invalid time. Hour must be between 0 and 23, Minute must be between 0 and 59.");
    }

    public Time(Time other)
    {
        // this() calls the parameter
        this(other.mHour, other.mMinute); // new change to protect its
    }

    public Time()
    {
        this(0, 0);
    }

    public int getHour()
    {
        return mHour;
    }

    public void setHour(int hour)
    {
        mHour = hour;
    }

    public int getMinute()
    {
        return mMinute;
    }

    public void setMinute(int minute)
    {
        mMinute = minute;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + mHour;
        result = prime * result + mMinute;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Time other = (Time) obj;
        if (mHour != other.mHour) return false;
        if (mMinute != other.mMinute) return false;
        return true;
    }

    @Override
    public String toString()
    {
        DecimalFormat twoDigits = new DecimalFormat("00");
        return "Time [" + twoDigits.format(mHour) + ":" + twoDigits.format(mMinute) + (isAM() ? " AM]" : " PM]");
    }

    public boolean isAM()
    {
        return (mHour < 12); // shortcut of if else
    }

    private boolean isValid(int hour, int minute)
    {
        return (hour >= 0 && hour < 24 && minute >= 0 && minute < 60);
    }

}