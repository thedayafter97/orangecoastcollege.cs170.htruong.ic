package edu.orangecoastcollege.cs170.htruong114.ic16;

public class TimeDemo
{

    public static void main(String[] args)
    {
        // Let's create 3 Time object (3:30pm), (3:30pm), (midnight)
        Time t1 = new Time(15, 30);
        Time t2 = new Time(t1);
        Time midnight = new Time(); // midnight = default constructor
        System.out.println(t1 + "\n" + t2 + "\n" + midnight);
        System.out.println();

        System.out.println(t1 + "\n" + t2);
        System.out.println((t1.equals(t2)) ? "The times are the same." : "The times are different.");
        System.out.println();

        System.out.println(t1 + "\n" + midnight);
        System.out.println((t1.equals(midnight)) ? "The times are the same." : "The times are different.");
    }
}