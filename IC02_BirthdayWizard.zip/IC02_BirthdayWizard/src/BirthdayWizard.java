import java.util.Scanner;
public class BirthdayWizard 
{

	public static void main(String[] args) 
	{
		int yourbirthyear, futureage, cal1, cal2;
		
		Scanner consoleScanner = new Scanner(System.in);
		
		System.out.println("Please enter your birth year...");
		yourbirthyear = consoleScanner.nextInt();
		cal1 = 2018 - yourbirthyear;
		System.out.println("You are " + cal1 + " years old.");
		
		System.out.println("\nPlease enter a future age...");
		futureage = consoleScanner.nextInt();
		cal2 = yourbirthyear + futureage;
		System.out.println("You will be " + futureage + " in the year " + cal2 + ".");
		
		consoleScanner.close();
	}

}
