import java.util.Scanner;

public class CountVonCount
{

    public static void main(String[] args)
    {
        int x; // x = magic number
        Scanner consoleScanner = new Scanner(System.in);
        
        System.out.println("What is the magic number of the day?");
        x = consoleScanner.nextInt();
        consoleScanner.close();
        
        if (x < 1)
            {
            System.err.println("I'm sorry, but the Count von Count only counts positive numbers!\nMuhahahaha");
            System.exit(0);
            }
        
        
        for (int i=1; i < x; i++)
        {
            
            System.out.print(i + ", ");
            
        }
        System.out.println(x);
        System.out.println("\n" + x + "! " + x + " is the magic number of the day. " + x 
                    + " dancing vegetables are here to celebrate with me! I love dancing vegetables!");
    }
}
