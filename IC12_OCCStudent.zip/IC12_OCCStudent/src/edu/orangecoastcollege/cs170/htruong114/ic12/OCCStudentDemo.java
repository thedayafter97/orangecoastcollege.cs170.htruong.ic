package edu.orangecoastcollege.cs170.htruong114.ic12;

public class OCCStudentDemo
{

    public static void main(String[] args)
    {
        // Instantiate (create) 2 new students
        // Use the CONSTRUCTOR method:

        // Let's turn ourselves into object
        OCCStudent hoa = new OCCStudent("C12456", "Hoa Truong", "htruong114", 20);
        // Let's print ourselves to the console
        hoa.setGPA(3.9);
        hoa.setFullName("Truong Keaton");
        System.out.println(hoa);

        // Let's make a second OCCStudent
        OCCStudent diane = new OCCStudent("C000015", "Diane Keaton", "dkeaton", 63);
        System.out.println(diane);

        // Let's test our miscellaneous methods:
        System.out.println("Is Hoa older than Diane? " + hoa.isOlder(diane));
        System.out.println("Is Hoa same age Diane? " + hoa.isSameAge(diane));
        System.out.println("Is Hoa younger than Diane? " + hoa.isYounger(diane));

        // Let's test our equals method:
        System.out.println("Is Hoa equal to Diane? " + hoa.equals(diane));
        System.out.println("Is Hoa equal to Hoa? " + hoa.equals(hoa));
    }
}