package edu.orangecoastcollege.cs170.htruong114.ic12;

// Data class = category of information
public class OCCStudent
{
    // 1) Fields (member variables) = information to store about each project
    // Define all field as private (to protect the database)
    // All field should begin with a prefix of "m" (member variable)
    private String mCNumber;
    private String mFullName;
    private String mUserName;
    private Double mGPA;
    private int mAge;
    
    // 2) Constructor - method to instantiate new objects
    // Like a Register, Sign Up or Submit button
    // Take information from a web form and saves it to database
    public OCCStudent(String cNumber, String fullName, String username, int age)
    {
        // Assign the database field to each of the parameters coming in\
        mCNumber = cNumber;
        mFullName = fullName;
        mUserName = username;
        mAge = age;
        mGPA = 0.0;
    }

    // 3) Accessors (getters) - provide read access to outside world
    // Retrieve value of a field
    public String getCNumber()
    {
        return mCNumber;
    }
    
    public String getFullName()
    {
        return mFullName;
    }
    
    public String getUserName()
    {
        return mUserName;
    }
    
    public Double getGPA()
    {
        return mGPA;
    } 
    
    public int getAge()
    {
        return mAge;
    }
    
    public void setFullName(String newFullName) 
    {
        // Save the new name to the database
        mFullName = newFullName;
    }
    
    public void setUserName(String newUserName) 
    {
        // Save the new name to the database
        mUserName = newUserName;
    }
    
    public void setAge(int newAge)
    {
        // Save the new name to the database
        mAge = newAge;
    }
    
    public void setGPA(Double newGPA)
    {
        mGPA = newGPA;
    }
    
    public String toString()
    {
        String output = "OCC Student[" + mCNumber + ", " + mFullName + ", " 
                        + mUserName + ", " + mAge + ", " + mGPA + "]";
        
        return output;
    }
    
    public boolean equals(OCCStudent other)
    {
        //   #1                       #2
        if (mFullName.equals(other.mFullName) && mCNumber.equals(other.mCNumber)
                && mUserName.equals(other.mUserName) && mAge == other.mAge 
                && mGPA == other.mGPA)
            return true;
        else 
            return false;
    }
    
    // 7) Miscellaneous Method(s)
    public boolean isOlder(OCCStudent other)
    {
        if (mAge > other.mAge)
            return true;
        else
            return false;
    }
    
    public boolean isSameAge(OCCStudent other)
    {
        if (mAge == other.mAge)
            return true;
        else
            return false;
    }
    
    public boolean isYounger(OCCStudent other) //other is #2 student
    {
        if (mAge < other.mAge)
            return true;
        else
            return false;
    }
}
