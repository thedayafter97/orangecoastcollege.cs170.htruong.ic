import java.util.Random;
import java.util.Scanner;

public class Magic8Ball
{

    public static void main(String[] args)
    {
        Random rng = new Random();
        int answer;
        String response, question;
        Scanner consoleScanner = new Scanner(System.in);
        do
        {
        System.out.println("What question would you like to ask the Magic 8 ball?");
        question = consoleScanner.nextLine();

        // answer should be random number between 1 and 8
        answer = rng.nextInt(8)+1;

        switch (answer)
        {
            case 1:
                System.out.println("The answer: It is certain");
                break;
            case 2:
                System.out.println("The answer: It is decidedly so");
                break;
            case 3:
                System.out.println("The answer: Most likely");
                break;
            case 4:
                System.out.println("The answer: Signs point to yes");
                break;
            case 5:
                System.out.println("The answer: Reply hazy, try again");
                break;
            case 6:
                System.out.println("The answer: Ask again later");
                break;
            case 7:
                System.out.println("The answer: Don't count on it");
                break;
            case 8:
                System.out.println("The answer: My sources say no");
                break;
        }
            System.out.println("\nWould you like to ask another question (type Y or N)");
            response = consoleScanner.nextLine().toUpperCase();
            System.out.println();
        }
        while (response.startsWith("Y"));
        consoleScanner.close();
        System.out.println("Thank you for playing the Magic 8 ball.");
    }

}
