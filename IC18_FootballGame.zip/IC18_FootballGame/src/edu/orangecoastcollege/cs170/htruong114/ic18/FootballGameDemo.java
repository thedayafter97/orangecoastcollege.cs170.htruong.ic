package edu.orangecoastcollege.cs170.htruong114.ic18;

import java.util.Scanner;

public class FootballGameDemo {

	public static void main(String[] args) 
	{
		String homeTeam, visitorTeam;
		int scoringEvent, team;
		
		Scanner consoleScanner = new Scanner(System.in);
		System.out.print("Please enter home team name: ");
		homeTeam = consoleScanner.nextLine();
		
		System.out.print("\nPlease enter visitor team name: ");
		visitorTeam = consoleScanner.nextLine();
		
		FootballGame game = new FootballGame(homeTeam, visitorTeam);
		
		do
		{
			System.out.print("\nEnter Scoring Event (or -1 end game):\n"
								+ "1) To score touchdown\n"
								+ "2) To score extra point\n"
								+ "3) To score conversation\n"
								+ "4) To score field goal\n"
								+ "5) To score safety\n"
								+ ">> ");
			scoringEvent = consoleScanner.nextInt();
			if (scoringEvent == -1)
			{
				consoleScanner.close();
				System.exit(0);
			}
			System.out.print("\nEnter Team:\n"
								+ "1) For " + homeTeam + " (home)\n"
								+ "2) For " + visitorTeam + " (visitor)\n"
								+ ">> ");
			team = consoleScanner.nextInt();
			System.out.println();
			
			switch (scoringEvent)
			{
			case 1: game.scoreTouchdown((team == 1) ? homeTeam : visitorTeam); break;
			case 2: game.scoreExtraPoint((team == 1) ? homeTeam : visitorTeam); break;
			case 3: game.scoreConversation((team == 1) ? homeTeam : visitorTeam); break;
			case 4: game.scoreFieldGoal((team == 1) ? homeTeam : visitorTeam); break;
			case 5: game.scoreSafety((team == 1) ? homeTeam : visitorTeam); break;
			}
			
			System.out.println(game);
			
		}while (scoringEvent != -1);
	}

}
