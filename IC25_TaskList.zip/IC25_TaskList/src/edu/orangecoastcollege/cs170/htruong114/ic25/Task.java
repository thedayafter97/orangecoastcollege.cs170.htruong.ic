package edu.orangecoastcollege.cs170.htruong114.ic25;

import java.io.Serializable;

public class Task implements Serializable
{
    private String mDeadline;
    private String mDueDate;
    private String mPriority;
    private String mName;
    
    public Task(String newName, String newDueDate, String newDeadLine, String newPriority)
    {
        super();
        mDeadline = newDeadLine;
        mDueDate = newDueDate;
        mPriority = newPriority;
        mName = newName;
    }
    public Task (Task otherTask){
        mDeadline = otherTask.mDeadline;
        mDueDate = otherTask.mDueDate;
        mPriority = otherTask.mPriority;
        mName = otherTask.mName;
    }
    public String getDeadline()
    {
        return mDeadline;
    }
    public String getDueDate()
    {
        return mDueDate;
    }
    public String getPriority()
    {
        return mPriority;
    }
    public String getName()
    {
        return mName;
    }
    public void setDeadline(String newDeadline)
    {
        mDeadline = newDeadline;
    }
    public void setDueDate(String newDueDate)
    {
        mDueDate = newDueDate;
    }
    public void setPriority(String newPriority)
    {
    	mPriority = newPriority;
    }
    public void setName(String newName)
    {
        mName = newName;
    }
    
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Task other = (Task) obj;
        if (mDeadline != other.mDeadline) return false;
        if (mDueDate != other.mDueDate) return false;
        if (mName == null)
        {
            if (other.mName != null) return false;
        }
        else if (!mName.equals(other.mName)) return false;
        if (mPriority != other.mPriority) return false;
        return true;
    }
    @Override
    public String toString()
    {	
        return "Task [Name=" + mName + ", Due Date=" + mDueDate + ", deadline=" + mDeadline + ", priority=" + mPriority + "]";
    }   
}