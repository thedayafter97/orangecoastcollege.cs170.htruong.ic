package edu.orangecoastcollege.cs170.htruong114.ic25;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class TaskListDemo
{
    @SuppressWarnings("unchecked")
	public static void main(String[] args)
    {
        Scanner consoleScanner = new Scanner(System.in);
        String taskName, deadLine, dueDate, priority;
        
        ArrayList<Task> taskList= new ArrayList<>();
        File binaryFile = new File("TaskList.dat");
        
        System.out.println("Previously saved Tasks from binary file:");
        if(binaryFile.exists())
        {
            try
            {
            	ObjectInputStream fileReader = new ObjectInputStream(new FileInputStream(binaryFile));
                taskList = (ArrayList<Task>)fileReader.readObject();
                fileReader.close();
                for (Task t :  taskList)
                    System.out.println(t);
            }
            catch (IOException | ClassNotFoundException e)
            {
                System.out.println(e.getMessage());
            }
        }
        else
            System.out.println("[None, please enter new Tasks]");
        
        do
        {
        	System.out.println("*******************************************");
            System.out.print("Please enter task name (or \"quit\" to exit): ");
            taskName = consoleScanner.nextLine();
            
            if(taskName.equalsIgnoreCase("quit")) break;
            
                System.out.print("Please enter due date (in form MM/DD/YYYY): ");
                dueDate = consoleScanner.nextLine();
                System.out.print("Please enter deadline: ");
                deadLine = consoleScanner.nextLine();
                System.out.print("Please enter prioirty: ");
                priority = consoleScanner.next();
                
                if(priority.equals("1"))
                	taskList.add(new Task(taskName, dueDate, deadLine, "High"));
                else if (priority.equals("2"))
                	taskList.add(new Task(taskName, dueDate, deadLine, "Medium"));
                else
                	taskList.add(new Task(taskName, dueDate, deadLine, "Low Priority"));
                
                consoleScanner.nextLine();
                
        }
        while(!taskName.equalsIgnoreCase("quit"));
        
        consoleScanner.close();
        
        try{
        	ObjectOutputStream fileWriter = new ObjectOutputStream(new FileOutputStream(binaryFile));
            fileWriter.writeObject(taskList);
            fileWriter.close();
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
        }
        
    }
}