import java.util.Scanner;
import java.text.DecimalFormat;
public class MortgagePayment 
{

	public static void main(String[] args) 
	{
		double mortgage, owed, interest, principal;
		Scanner consoleScanner = new Scanner(System.in);
		DecimalFormat twoDPs = new DecimalFormat("0,000.00");
		
		System.out.print("Please enter your mortgage payment: $");
		mortgage = consoleScanner.nextDouble();
		
		System.out.print("Please enter outstanding balance on mortgage: $");
		owed = consoleScanner.nextDouble();
		
		//Assume that the annual interest rate is 4% (which is the current rate).	
		interest = (owed * 0.04) / 12;
		principal = mortgage - interest;
		
		
		System.out.println("\nOf your $" + twoDPs.format(mortgage) + " mortgage payment:\n"
							+	"$" + twoDPs.format(interest) + " goes to interest\n"
							+   "$" + twoDPs.format(principal) + " goes to principal");
		
		consoleScanner.close();
	}

}
