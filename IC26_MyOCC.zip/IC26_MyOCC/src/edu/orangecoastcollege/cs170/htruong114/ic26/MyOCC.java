package edu.orangecoastcollege.cs170.htruong114.ic26;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class MyOCC
{

    public static void main(String[] args)
    {
        int countS = 0;
        String username, course;
        Scanner consoleScanner = new Scanner(System.in);

        ArrayList<String> coursesList = new ArrayList<>(20);
        HashMap<String, ArrayList<String>> myOCC = new HashMap<>();

        System.out.println("~~~~~~~~~~~~~~~~~Welcome to MyOCC ~~~~~~~~~~~~~~~~~");
        do
        {
            System.out.print("\nPlease enter student username (or \"quit\" to exit): ");
            username = consoleScanner.nextLine();
            if (username.equalsIgnoreCase("quit"))
                break;

            System.out.print("Please enter course to enroll in: ");
            course = consoleScanner.nextLine();

            // if the username is already in my occ, add the new
            if (myOCC.containsKey(username))
                // get the old list of courses
                coursesList = myOCC.get(username);
            // else, create a new ArrayList, add the new course and put in myOCC
            else
                coursesList = new ArrayList<>(20);

            // Add the new one
            coursesList.add(course);
            // put the list back into hashmap
            myOCC.put(username, coursesList);

        }
        while (!username.equalsIgnoreCase("quit"));
        consoleScanner.close();

        System.out.println("\n~~~~~~~~~~~~~~~Spring 2017 Enrollment~~~~~~~~~~~~~~~");

        for (String student : myOCC.keySet())
        {
            System.out.println("\nStudent: " + student
                             + "\nCourses: " + myOCC.get(student));
            countS ++;
        }

        int total = 0;
        //Let's loop through the values
        for (ArrayList<String> courses : myOCC.values())
           total += courses.size();

        String mostFrequent = "";
        int maxCount = 0;
        for (String name : myOCC.keySet())
        {
            ArrayList<String> value = myOCC.get(name);
            if (value.size() > maxCount)
            {
                maxCount = value.size();
                mostFrequent = name;
            }
        }
        System.out.print("\nTotal students enrolled: " + countS
                       + "\nTotal courses enrolled: " + total
                       + "\nStudent with most courses: " + mostFrequent);

    }

}