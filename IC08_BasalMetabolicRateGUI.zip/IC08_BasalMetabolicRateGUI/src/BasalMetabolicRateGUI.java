import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.text.DecimalFormat;

public class BasalMetabolicRateGUI extends JFrame
{
    public static final int CHOCOLATE_BAR_CALORIES = 230;

    public static void main(String[] args)
    {
        double weight, height, age, bmr, bars;
        
        int gender;
        
        String activity;
        
        // Use scanner for user input
        DecimalFormat noDP = new DecimalFormat("0");
        DecimalFormat oneDP = new DecimalFormat("0.0");

        // User input
        weight = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter your weight in pound:", "Input", JOptionPane.QUESTION_MESSAGE));
        
        height = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter your height in inches:", "Input", JOptionPane.QUESTION_MESSAGE));
        
        age = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter your age in years:", "Input", JOptionPane.QUESTION_MESSAGE));
        
        // Let's make our first showOptionDialog!
        // Start by defining the custom buttons in an ARRAY:
        String[] buttons = {"Female", "Male"}; // buttons {0 1}
        gender = JOptionPane.showOptionDialog(null, 
                "Calculate BMR for female or male:", 
                "Identify Gender", 
                JOptionPane.DEFAULT_OPTION, // enter from keyboard
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                buttons, 
                buttons[0]); //default button ( 0 = female, 1 = male, *2 = alien* )

        // Let's make a decision to determine gender
        // BMR calculation with Harris-Benedict equation
        if (gender == 0)
            bmr = 655 + (4.35 * weight) + (4.7 * height) - (4.7 * age);
        else
            bmr = 66 + (6.23 * weight) + (12.7 * height) - (6.8 * age);

        
        String[] options = {"Sedentary","Somewhat Active","Active","Highly Active"};
        Object selectedValue = JOptionPane.showInputDialog(null, 
                    "Select activity level:", 
                    "BMR Activity Level", 
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]);
        activity = selectedValue.toString();
        
        
        switch (activity)
        {
            case "Sedentary": // Sedentary, increase bmr by 20%
                bmr *= 1.2;
                break;
            case "Somewhat Active": // Somewhat active, increase by 30%
                bmr *= 1.3;
                break;
            case "Active": // Active, increase by 40%
                bmr *= 1.4;
                break;
            default:// Highly Active, increase by 50%
                bmr *= 1.5;
        }
        // Number of chocolate bars needed to maintain BMR
        bars = bmr / CHOCOLATE_BAR_CALORIES;

        // Display output to the user
        JOptionPane.showMessageDialog(null, "As a " + buttons[gender] + " your BMR x Activity Factor is " + noDP.format(bmr)
                        + " and you need to eat " + oneDP.format(bars) 
                        + " chocolate bars to maintain this amount of calories.", 
                        "Message", JOptionPane.INFORMATION_MESSAGE);
    }
}