
public class NestedShapes
{

    public static void main(String[] args)
    {
        for (int row = 1; row <= 4; row++)
        {
            for (int col = 1; col <= 4; col++)
            {
                System.out.print("*");
            }
            System.out.println();
        }
        System.out.println();

        for (int number = 1; number <= 4; number++)
        {
            for (int samenum = 1; samenum <= 4; samenum++)
            {
                System.out.print(number);
            }
            System.out.println();
        }
        System.out.println();
        
        for (int line = 1; line <= 4; line++)
        {
        	for (int star = 1; star <= line; star++)
        	{
        		System.out.print("*");
        	}
        	System.out.println();
        }
        System.out.println();
        
        for (int i = 1; i <= 4; i++)
        {
        	for (int j = 1; j <= i; j++)
        	{
        		System.out.print(i);
        	}
        	System.out.println();
        }
    }
}
