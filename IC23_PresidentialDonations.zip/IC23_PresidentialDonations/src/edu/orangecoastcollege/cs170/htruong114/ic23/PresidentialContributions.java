package edu.orangecoastcollege.cs170.htruong114.ic23;

import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Scanner;

public class PresidentialContributions
{

    public static void main(String[] args)
    {
        double sum = 0.0, average, min = Double.MAX_VALUE, max = Double.MIN_VALUE, donation;
        int contributors = 0;

        // open a text file in Java with the Scanner class
        try
        {
            Scanner fileScanner = new Scanner(new File("clinton2016donations.txt"));
            // Loop through all the donations one by one:
            // use a "while" loop because the file could be empty
            // while = "as long as"
            // As long as the file has another double value to read, keep looping

            while (fileScanner.hasNextDouble())
            {
                // Donation amount comes from the file:
                donation = fileScanner.nextDouble();
                // Add it to the sum
                sum += donation;
                // Add one to the number of contributors
                contributors++;
                // Determine if the donation is a min
                if (donation < min)
                    min = donation;
                // Determine if the donation is a max
                if (donation > max)
                    max = donation;

            }
            // After the loop, close the file
            fileScanner.close();
            // Print all the statistics for that candidate:
            NumberFormat currency = NumberFormat.getCurrencyInstance();
            System.out.println("For candidate: Hillary Clinton\n"
                           + "The minimum contribution was: " + currency.format(min) + "\n"
                           + "The maximum contributrion was: " + currency.format(max) + "\n"
                           + "The average contribution was: " + currency.format(average = (sum / contributors)) + "\n"
                           + "The number of contributions was: " + contributors + "\n"
                           + "The total amount contributed was: " + currency.format(sum));

        }
        catch (IOException e)
        {
            System.out.println("File not found.");
        }

        // Reset the value
        sum = 0.0;
        contributors = 0;
        try
        {
            Scanner fileScanner = new Scanner(new File("trump2016donations.txt"));
            // Loop through all the donations one by one:
            // use a "while" loop because the file could be empty
            // while = "as long as"
            // As long as the file has another double value to read, keep looping

            while (fileScanner.hasNextDouble())
            {
                // Donation amount comes from the file:
                donation = fileScanner.nextDouble();
                // Add it to the sum
                sum += donation;
                // Add one to the number of contributors
                contributors++;
                // Determine if the donation is a min
                if (donation < min)
                    min = donation;
                // Determine if the donation is a max
                if (donation > max)
                    max = donation;

            }
            // After the loop, close the file
            fileScanner.close();
            // Print all the statistics for that candidate:
            NumberFormat currency = NumberFormat.getCurrencyInstance();
            System.out.print("\nFor candidate: Donald Trump\n"
                           + "The minimum contribution was: " + currency.format(min) + "\n"
                           + "The maximum contributrion was: " + currency.format(max) + "\n"
                           + "The average contribution was: " + currency.format(average = (sum / contributors)) + "\n"
                           + "The number of contributions was: " + contributors + "\n"
                           + "The total amount contributed was: " + currency.format(sum));

        }
        catch (IOException e)
        {
            System.out.println("File not found.");
        }

    }

}
