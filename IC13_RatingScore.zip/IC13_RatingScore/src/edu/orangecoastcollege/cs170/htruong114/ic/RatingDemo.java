package edu.orangecoastcollege.cs170.htruong114.ic;

public class RatingDemo
{

    public static void main(String[] args)
    {
    	//test constructor
    	// test set
    	// test toString
        Rating film1 = new Rating("Titanic movie", 4.75, 5.0, "Feel romantic");
        film1.setComments("Too sleepy");
        film1.setDescription("Spider Man");
        film1.setMaxScore(10.0);
        film1.setScore(8.25);
        System.out.println(film1);
        
        Rating film2 = new Rating("The Flash", 5.5, 5.5, "Feel really good about action and fiction");
        System.out.println(film2);
        
        // test equals
        System.out.println("\nIs film1 equal to film2? " + film1.equals(film2));
    }

}