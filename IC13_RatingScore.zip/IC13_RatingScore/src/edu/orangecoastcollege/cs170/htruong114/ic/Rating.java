package edu.orangecoastcollege.cs170.htruong114.ic;

public class Rating
{

    private String mComments;
    private String mDescription;
    private Double mMaxScore;
    private Double mScore;

    public Rating(String description, Double score, Double maxScore, String comments)
    {
        mComments = comments;
        mDescription = description;
        mMaxScore = maxScore;
        mScore = score;
    }

    public String getComments()
    {
        return mComments;
    }

    public String getDescription()
    {
        return mDescription;
    }

    public Double getMaxScore()
    {
        return mMaxScore;
    }

    public Double getScore()
    {
        return mScore;
    }

    public void setComments(String newComments)
    {
        mComments = newComments;
    }

    public void setDescription(String newDescription)
    {
        mDescription = newDescription;
    }

    public void setMaxScore(Double newMaxScore)
    {
        mMaxScore = newMaxScore;
    }

    public void setScore(Double newScore)
    {
        mScore = newScore;
    }

    public String toString()
    {
        String output = "Rating [" + mDescription + ", " + mScore + ", " + mMaxScore + ", " + mComments + ".]";
        return output;
    }

    public boolean equals(Rating other)
    {
        if (mComments.equals(other.mComments) && mDescription.equals(other.mDescription) && mMaxScore == other.mMaxScore
                && mScore == other.mScore)
            return true;
        else
            return false;
    }
}