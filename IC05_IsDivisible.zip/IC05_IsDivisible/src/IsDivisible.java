import java.util.Scanner;

public class IsDivisible
{

    public static void main(String[] args)
    {
        int x, y;
        Scanner consoleScanner= new Scanner(System.in);

        System.out.print("Please enter a number for x: ");
        x = consoleScanner.nextInt();

        System.out.print("Please enter a number for y: ");
        y = consoleScanner.nextInt();
        consoleScanner.close();
         if (x % y == 0)
         {
             System.out.println("\n" + x + " is divisible by " + y);
         }
         else
         {
             System.out.println("\n" + x + " is NOT divisible by " +y);
         }
    }

}
