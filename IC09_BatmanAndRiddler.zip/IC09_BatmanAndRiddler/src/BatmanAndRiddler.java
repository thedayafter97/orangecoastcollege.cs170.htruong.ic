public class BatmanAndRiddler 
{

	public static void main(String[] args) 
	{
		for (int address = 1001; address <= 9999; address += 2) // the number is odd
		{
		    
		    int d4 = address % 10;
		    int d3 = address / 10 % 10;
		    int d2 = address / 100 % 10;
		    int d1 = address / 1000 % 10;
		    
		    
		    if (d1 != (d3 * 3))	
		    	continue;

		    if (d1 != d2 && d1 != d3 && d1 != d4 && d2 != d3 && d2 != d4 && d3 != d4)
		    	
		    if ((d1 + d2 + d3 + d4) == 27)
		            System.out.println("The Riddler intends to strike " + address + " Pennsylvania Avenue.");
		}
	}
}