import java.util.Scanner;
import java.text.DecimalFormat;
public class Tipping
{

	public static void main(String[] args)
	{
		double bill, tippercentage, totaltax, totaltip, total;

		Scanner consoleScanner = new Scanner(System.in);
		DecimalFormat twoDPs = new DecimalFormat("0.00");

		System.out.print("Please enter amount of restaurant bill $");
		bill = consoleScanner.nextDouble();

		System.out.print("Please enter the tip percentage (%) ");
		tippercentage = consoleScanner.nextDouble();

		//The tax rate in Costa Mesa is currently 8.00%
		totaltax = (bill * 8) / 100;
		System.out.println("\nThe total taxes are $" + twoDPs.format(totaltax));

		totaltip = ((bill + totaltax) * tippercentage) / 100;
		System.out.println("The tip amount is $" + twoDPs.format(totaltip));

		total = bill + totaltax + totaltip;
		System.out.println("\nThe total amount to pay is $" + twoDPs.format(total));

		consoleScanner.close();
	}

}