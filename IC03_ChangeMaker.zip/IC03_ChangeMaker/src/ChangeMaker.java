import java.util.Scanner;
public class ChangeMaker 
{

	public static void main(String[] args) 
	{
		int number, quarter, dime, nickel, penny;
		Scanner consoleScanner = new Scanner(System.in);
		
		System.out.println("Enter a whole number from 1 to 99.\nI will find a combination of coins to equal that amount of change.");
		number = consoleScanner.nextInt();
		
		
		System.out.println("\n" + number + " cents in coins can be given as:");
		
		
		quarter = ( number - (number % 25) ) / 25;
		
		dime = ((number - quarter*25) - (number % 25 % 10)) / 10;
		
		nickel = ((number - quarter*25 - dime*10) - (number % 25 % 10 % 5)) / 5;
		
		penny = ((number - quarter*25 - dime*10 - nickel*5) - (number % 25 % 10 % 5 % 1)) / 1;
		
		System.out.println(quarter + " quarter(s)\n"
						+ dime + " dime(s)\n"
						+ nickel + " nickel(s)\n"
						+ penny + " penny(ies)");
		
		consoleScanner.close();
	}

}
