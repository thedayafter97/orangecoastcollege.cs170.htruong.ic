import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JApplet;

public class LoopyFaces extends JApplet
{

	public void init() {setSize(1020,570);}
	public void paint (Graphics canvas)
	{
		Graphics2D canvas2D = (Graphics2D) canvas;
		
		RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        canvas2D.setRenderingHints(rh);
        
        int x = 10, y = 10; // circle
        int xly = 35, yly = 35; // left eye
        int xry = 75, yry = 35; // right eye
        int xn = 55, yn = 55; // nose
        int xm = 35, ym = 75; // mouth
        Color occOrange = new Color(245, 146, 59);
        
        for (int i = 1; i <= 10; i++)
        {
            // Make decision to see what color
            // If circle is odd, RED
            // Else, WHITE
            if (i % 2 != 0)
            {	canvas.setColor(occOrange);
            	canvas.fillOval(x, y, 100, 100);
            	canvas.setColor(Color.BLACK);
            	canvas.fillOval(xly, yly, 10, 15);// left eye
            	canvas.fillOval(xry, yry, 10, 15);// right eye
            	canvas.fillOval(xn, yn, 10, 10);// nose
            	canvas2D.setStroke(new BasicStroke(2));
            	canvas.drawArc(xm, ym, 50, 15, 0, -180); //mouth
            }
            else
            {   canvas.setColor(Color.BLUE);
            	canvas.fillOval(x, y, 100, 100);
            	canvas.setColor(Color.BLACK);
            	canvas.fillOval(xly, yly, 10, 15);// left eye
            	canvas.fillOval(xry, yry, 10, 15);// right eye
            	canvas.fillOval(xn, yn, 10, 10);// nose
            	canvas2D.setStroke(new BasicStroke(2));
            	canvas.drawArc(xm, ym, 50, 15, 0, -180); //mouth
            }
            x += 100;
            y += 50;
            xly += 100;
            yly += 50;
            xry += 100;
            yry += 50;
            xn += 100;
            yn += 50;
            xm += 100;
            ym += 50;
        }
	}
}