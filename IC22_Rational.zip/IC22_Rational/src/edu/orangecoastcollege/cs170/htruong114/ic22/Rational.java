package edu.orangecoastcollege.cs170.htruong114.ic22;

public class Rational 
{
	private int mNumerator;
	private int mDenominator;
	
	//anytime has the keyword throws, means whoever uses it
	//must surround it with try/catch
	public Rational(int numerator, int denominator) throws ZeroDenominatorException 
	{
		mNumerator = numerator;
		// Use the setDenominator method to check for exceptions
		setDenominator(denominator);
	}

	public int getNumerator() {
		return mNumerator;
	}

	public void setNumerator(int numerator) {
		mNumerator = numerator;
	}

	public int getDenominator() {
		return mDenominator;
	}

	//throws alerts other programmers that the method may generate an exception
	//to use it, you have to try/catch it.
	public void setDenominator(int denominator) throws ZeroDenominatorException {
		//Prevent the denominator from ever being 0
		//If it's 0, we will generate a ZeroDenominatorException
		// Throw (generate) the exception from data class,
		// try and catch it in the demo.
		if (denominator == 0)
			throw new ZeroDenominatorException();
		mDenominator = denominator;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mDenominator;
		result = prime * result + mNumerator;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rational other = (Rational) obj;
		if (mDenominator != other.mDenominator)
			return false;
		if (mNumerator != other.mNumerator)
			return false;
		return true;
	}

	@Override
	public String toString() {
		if (mDenominator < 0)
		{
			mNumerator *= -1;
			mDenominator *= -1;
		}
		
		return mNumerator + "/" + mDenominator;
	}
	
	
	

}
