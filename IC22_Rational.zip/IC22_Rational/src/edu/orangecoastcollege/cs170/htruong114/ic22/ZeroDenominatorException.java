package edu.orangecoastcollege.cs170.htruong114.ic22;

// ZeroDenominatorException is an Exception
public class ZeroDenominatorException extends Exception
{
	public ZeroDenominatorException()
	{
		// super refers to the constructor in the parent class
		super("Division by zero is undefined.");
	}
	
	public ZeroDenominatorException(String customMessage)
	{
		super(customMessage);
	}

}
