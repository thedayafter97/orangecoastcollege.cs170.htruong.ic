
public class strings {

}
