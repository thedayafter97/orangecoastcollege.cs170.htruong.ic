import java.util.Scanner;
public class ValidDate 
{

	public static void main(String[] args) 
	{
		String date, monthPart, dayPart, yearPart;
		int month, day, year;
		Scanner consoleScanner = new Scanner(System.in);
		
		
		System.out.println("Please enter date in the form mm/dd/yyyy: ");
		date = consoleScanner.next(); // 02/20/2018
		consoleScanner.close();
		
		monthPart = date.substring(0, 2); // "02"
		dayPart = date.substring(3, 5);   // "20"
		yearPart = date.substring(6);     // "2018"
		
		// To convert String into ints, use Integer.parseInt(...)
		month = Integer.parseInt(monthPart);  // 2
		day = Integer.parseInt(dayPart);      // 20
		year = Integer.parseInt(yearPart);    // 2018
		
		// Decision to see if the day is INVALID:
            switch (month)
            {
				case 1:
				case 3:
				case 5:
				case 7:
				case 8:
				case 10:
				case 12:
					if (day < 1 || day > 31)
					{
						System.err.println("\nInvalid day.");
						System.err.println("January, March, May, July, August, October, December each have 31 days.\n"
										+ "A valid day value dd must be from 01 to 31 days.");
					}
					else 
						System.out.println("\n" + monthPart + "/" + dayPart + "/" + yearPart + " is a valid date.");
				break;
			
				case 2:
						if (day < 1 || day > 28)
						{
						System.err.println("\nInvalid day.");
						System.err.println("February has 28 days.\n"
										+ "A valid day value dd must be from 01 to 28 days.");
						}
						else 
							System.out.println("\n" + monthPart + "/" + dayPart + "/" + yearPart + " is a valid date.");
				break;
				
				case 4:
				case 6:
				case 9:
				case 11:
					if (day < 1 || day > 30)
					{
						System.err.println("\nInvalid day.");
						System.err.println("September, April, June, and November each have 30 days.\n"
								+ "A valid day value dd must be from 1 to 30 days.");
					}
					else 
						System.out.println("\n" + monthPart + "/" + dayPart + "/" + yearPart + " is a valid date.");
				break;
			
				default:
					System.err.print("\nInvalid month\n" + "A valid month value mm must be from 01 to 12 (January is 01).");
				break;
            }       
	}

}
