package edu.orangecoastcollege.cs170.htruong114.ic19;

import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Random;

public class WinningTheLottery
{

    public static final int SIZE = 5;

    public static void main(String[] args)
    {
        int[] winningNumbers = new int[SIZE];
        int[] guessNumbers = new int[SIZE];
        int spent = 0;
        // fill the winning number!
        randomlyAssignNumbers(winningNumbers);

        System.out.println("The winning lottery numbers are:\n" + Arrays.toString(winningNumbers));

        // Keep looping until 5 out of 5 of the guessNumbers equal winningNumber
        do
        {
            // fill out the guess numbers!
            randomlyAssignNumbers(guessNumbers);
            spent++;

        }
        while (howManyCorrect(winningNumbers, guessNumbers) < 5);

        NumberFormat currency = NumberFormat.getCurrencyInstance();
        // after the loop, we WON the Lottery!
        System.out.println(
                "After spending " + currency.format(spent) + ", you won the Fantasy 5 lottery! 5 out of 5 lottery numbers were correct. You win $75,000");

    }

    // make a method named howManyCorrect, takes in 2 arrays and returns
    // how many of the numbers are the same

    public static int howManyCorrect(int[] array1, int[] array2)
    {
        int count = 0;
        for (int i = 0; i < array1.length; i++)
        {
            if (array1[i] == array2[i]) count++;
        }
        return count;
    }

    public static void randomlyAssignNumbers(int[] anyArray)
    {
        Random rng = new Random();
        for (int i = 0; i < anyArray.length; i++)
        {
            // Random number between 0 and 36
            anyArray[i] = rng.nextInt(37);
        }
    }

}
