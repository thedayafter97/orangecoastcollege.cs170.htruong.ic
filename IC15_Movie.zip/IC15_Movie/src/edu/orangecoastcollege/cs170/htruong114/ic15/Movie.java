package edu.orangecoastcollege.cs170.htruong114.ic15;

public class Movie {
	private String mName;
	private String mDirector;
	private MPAARating mMPPARating;
	private int mTerribleNumber;
	private int mBadNumber;
	private int mOkNumber;
	private int mGoodNumber;
	private int mExcellentNumber;

	public Movie(String name, String director, MPAARating mPPARating) {
		super();
		mDirector = director;
		mMPPARating = mPPARating;
		mName = name;
	}

	public Movie(Movie other) {
		mName = other.mName;
		mDirector = other.mDirector;
		mMPPARating = other.mMPPARating;
	}

	public String getDirector() {
		return mDirector;
	}

	public void setDirector(String director) {
		mDirector = director;
	}

	public MPAARating getMPPARating() {
		return mMPPARating;
	}

	public void setMPPARating(MPAARating mPPARating) {
		mMPPARating = mPPARating;
	}

	public String getName() {
		return mName;
	}

	public void setName(String name) {
		mName = name;
	}

	public int getBadNumber() {
		return mBadNumber;
	}

	public int getExellentNumber() {
		return mExcellentNumber;
	}

	public int getGoodNumber() {
		return mGoodNumber;
	}

	public int getOkNumber() {
		return mOkNumber;
	}

	public int getTerribleNumber() {
		return mTerribleNumber;
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mBadNumber;
		result = prime * result + ((mDirector == null) ? 0 : mDirector.hashCode());
		result = prime * result + mExcellentNumber;
		result = prime * result + mGoodNumber;
		result = prime * result + ((mMPPARating == null) ? 0 : mMPPARating.hashCode());
		result = prime * result + ((mName == null) ? 0 : mName.hashCode());
		result = prime * result + mOkNumber;
		result = prime * result + mTerribleNumber;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (mBadNumber != other.mBadNumber)
			return false;
		if (mDirector == null) {
			if (other.mDirector != null)
				return false;
		} else if (!mDirector.equals(other.mDirector))
			return false;
		if (mExcellentNumber != other.mExcellentNumber)
			return false;
		if (mGoodNumber != other.mGoodNumber)
			return false;
		if (mMPPARating != other.mMPPARating)
			return false;
		if (mName == null) {
			if (other.mName != null)
				return false;
		} else if (!mName.equals(other.mName))
			return false;
		if (mOkNumber != other.mOkNumber)
			return false;
		if (mTerribleNumber != other.mTerribleNumber)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Movie [Name=" + mName + ", Director=" + mDirector + ", MPPARating=" + mMPPARating + ", Average Rating="
				+ calculateAverageRating() + "]";
	}
	
	public double calculateAverageRating() {

		double calculates = (mTerribleNumber * 1 + mBadNumber * 2 + mOkNumber * 3 + mGoodNumber * 4
				+ mExcellentNumber * 5) / 5.0;
		return calculates;

	}

	public boolean addRating(int rating) {
		if (rating >= 1 && rating <= 5) {
			switch (rating) {
			case 1:
				mTerribleNumber++;
				break;
			case 2:
				mBadNumber++;
				break;
			case 3:
				mOkNumber++;
				break;
			case 4:
				mGoodNumber++;
				break;
			case 5:
				mExcellentNumber++;
				break;
			}
			return true;
		} else
			return false;
	}

	public boolean removeRating(int rating) {
		if (rating > 0) {
			switch (rating) {
			case 1:
				if (mTerribleNumber > 0)
					mTerribleNumber--;
				else
					return false;
				break;
			case 2:
				if (mBadNumber > 0)
					mBadNumber--;
				else
					return false;
				break;
			case 3:
				if (mOkNumber > 0)
					mOkNumber--;
				else
					return false;
				break;
			case 4:
				if (mGoodNumber > 0)
					mGoodNumber--;
				else
					return false;
				break;
			case 5:
				if (mExcellentNumber > 0)
					mExcellentNumber--;
				else
					return false;
				break;
			}
			return true;
		} else
			return false;

	}

}