package edu.orangecoastcollege.cs170.htruong114.ic15;

public enum MPAARating 
{
	G,
	PG,
	PG_13,
	R,
	NC_17;
}
