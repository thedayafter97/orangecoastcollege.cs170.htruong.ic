package edu.orangecoastcollege.cs170.htruong114.ic15;

import java.util.Scanner;

public class MovieDemo {

	public static void main(String[] args) 
	{
		Movie movie1 = new Movie("Orange County", "Jake Kasdan", MPAARating.PG_13);
		Movie movie2 = new Movie(movie1);
		System.out.println(movie1 + "\n" + movie2);

		System.out.println(movie1.equals(movie2) ? "Both movies are the same." : "The movies are different.");
		System.out.println();
		
		movie2.setDirector("Hoa Truong");
		movie2.setMPPARating(MPAARating.NC_17);
		movie2.setName("My HomeTown");
		System.out.println(movie1 + "\n" + movie2);
		System.out.println(movie1.equals(movie2) ? "Both movies are the same." : "The movies are different.");
		System.out.println();
		
		//Add ratings
		movie1.addRating(1);
		movie1.addRating(1);
		movie1.addRating(1);
		movie1.addRating(2);
		movie1.addRating(3);
		
		movie2.addRating(5);
		movie2.addRating(5);
		movie2.addRating(5);
		movie2.addRating(5);
		movie2.addRating(4);
		
		System.out.println(movie1 + "\n" + movie2);
		System.out.println(movie1.equals(movie2) ? "Both movies are the same." : "The movies are different.");
		System.out.println();
		
		//Remove ratings
		movie1.removeRating(1);
		movie1.removeRating(2);
		
		movie2.removeRating(5);
		movie2.removeRating(5);
		System.out.println(movie1 + "\n" + movie2);
		System.out.println(movie1.equals(movie2) ? "Both movies are the same." : "The movies are different.");
	}	
}