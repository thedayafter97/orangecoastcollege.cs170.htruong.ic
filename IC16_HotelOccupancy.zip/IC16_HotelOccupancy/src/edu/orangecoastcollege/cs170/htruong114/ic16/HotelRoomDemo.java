package edu.orangecoastcollege.cs170.htruong114.ic16;

public class HotelRoomDemo
{

    public static void main(String[] args)
    {
        HotelRoom room101 = new HotelRoom(101, 4);
        System.out.println(room101);

        // Static variables and methods belong to the CLASS not the object
        System.out.println(HotelRoom.getTotalOccupants());

        HotelRoom room102 = new HotelRoom(102, 2);
        System.out.println(room102);
        System.out.println(HotelRoom.getTotalOccupants());
        System.out.println();

        // Let's remove 4 people from 101 and 4 people from room102
        room101.removeFromRoom(4);
        room102.removeFromRoom(4);

        System.out.println(room101 + "\n" + room102);
        System.out.println(HotelRoom.getTotalOccupants());
        System.out.println();

        room101.addToRoom(3);
        room102.addToRoom(3);
        System.out.println(room101 + "\n" + room102);
        System.out.println(HotelRoom.getTotalOccupants());
    }

}
