package edu.orangecoastcollege.cs170.htruong114.ic16;

public class HotelRoom
{
    // Member variables (fields): each object gets its own copy
    private int mRoomNumber;
    private int mPeople;

    // Static variable(s): only one copy for whole class (ALL objects share)
    private static int sTotalOccupants = 0;

    public HotelRoom(int roomNumber, int people)
    {
        super();
        mRoomNumber = roomNumber;
        mPeople = people;
        sTotalOccupants += people;
    }

    public int getRoomNumber()
    {
        return mRoomNumber;
    }

    public int getPeople()
    {
        return mPeople;
    }

    public static int getTotalOccupants()
    {
        return sTotalOccupants;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + mPeople;
        result = prime * result + mRoomNumber;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        HotelRoom other = (HotelRoom) obj;
        if (mPeople != other.mPeople) return false;
        if (mRoomNumber != other.mRoomNumber) return false;
        return true;
    }

    @Override
    public String toString()
    {
        return "HotelRoom [RoomNumber=" + mRoomNumber + ", People=" + mPeople + "]";
    }

    public boolean addToRoom(int numberOfPeople)
    {
        if ((mPeople + numberOfPeople) <= 4)
        {
            // make the number of people in the room go up by that amount
            mPeople += numberOfPeople;//increases the value of totalOccupancy by the same amount
            sTotalOccupants += numberOfPeople;
            return true;
        }
        else
            return false;
    }

    public boolean removeFromRoom(int numberOfPeople)
    {
        if ((mPeople - numberOfPeople) >= 0)
        {
            mPeople -= numberOfPeople; //decreases the value of totalOccupancy by the same amount
            sTotalOccupants -= numberOfPeople;
            return true;
        }
        else
            return false;
    }
}