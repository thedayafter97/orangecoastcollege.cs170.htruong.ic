package edu.orangecoastcollege.cs170.htruong114.ic16;

public class TemperatureDemo {

	public static void main(String[] args) {
		Temperature tempF = new Temperature(45, TemperatureUnit.FAHRENHEIT);
        Temperature tempC = new Temperature();
        System.out.println(tempF + "\n" + tempC);
        System.out.println(tempF.equals(tempC) ? "The temperatures are the same." : "The temperatures are different.");
        
        System.out.println();
        
        tempC.setDegrees(45);
        System.out.println(tempF + "\n" + tempC);
        System.out.println(tempF.equals(tempC) ? "The temperatures are the same." : "The temperatures are different.");
        System.out.println();
        
        tempF.convertTo(TemperatureUnit.FAHRENHEIT);
        tempC.convertTo(TemperatureUnit.FAHRENHEIT);
        System.out.println(tempF + "\n" + tempC);
        System.out.println(tempF.equals(tempC) ? "The temperatures are the same." : "The temperatures are different.");
        System.out.println();
        
        Temperature newTemp =  tempC.inOtherUnit(TemperatureUnit.FAHRENHEIT);
        System.out.println(newTemp + "\n" + tempC);
        System.out.println(newTemp.equals(tempC) ? "The temperatures are the same." : "The temperatures are different.");
	}

}