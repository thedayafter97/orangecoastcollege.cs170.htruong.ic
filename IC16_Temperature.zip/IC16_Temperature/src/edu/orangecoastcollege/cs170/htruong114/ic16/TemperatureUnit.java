package edu.orangecoastcollege.cs170.htruong114.ic16;

public enum TemperatureUnit 
{
	FAHRENHEIT,
	CELSIUS
}
