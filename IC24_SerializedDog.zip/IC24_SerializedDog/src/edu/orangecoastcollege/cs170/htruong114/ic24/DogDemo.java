package edu.orangecoastcollege.cs170.htruong114.ic24;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class DogDemo
{

    @SuppressWarnings("unchecked")
    public static void main(String[] args)
    {
        Scanner consoleScanner = new Scanner(System.in);
        double age;
        String name, breed;

        // ArrayList to store all the dogs:
        ArrayList<Dog> dogsList = new ArrayList<>();

        // Define the binary file used to store Dogs (database)
        File binaryFile = new File("Dog.dat");
        // Check to see if the file exists. If so, read in the Dog data
        // from the file into the array list (dogsList)
        System.out.println("Previously saved dogs from the binary file:");
        if (binaryFile.exists())
        {
            // Read from binary file (ObjectInputStream) into the array list
            // (dogsList)
            try
            {
                ObjectInputStream fileReader = new ObjectInputStream(new FileInputStream(binaryFile));
                // Use the fileReader to read into the array list (dogsList)
                dogsList = (ArrayList<Dog>) fileReader.readObject();
                // The line of code above reads ALL dogs from database into
                // dogsList
                // Done reading, so close the file
                fileReader.close();
                // Print all the dogs from dogsList
                for (Dog d : dogsList)
                    System.out.println(d);
            }
            catch (IOException | ClassNotFoundException e)
            {
                System.out.println(e.getMessage());
            }

        }
        else
            System.out.println("[None, Please enter new dog data]");

        // Loop as long as the user does not type "quit"
        do
        {
         // 1) Prompt user to enter:
            // name, breed, age

            // 2) Create Dog object

            // 3) Add the Dog to the array list

            System.out.println("****************************************");
            System.out.print("Please enter dog's name (or -1 to exit): ");
            name = consoleScanner.nextLine();

            // check to see if name is -1
            if (name.equals("-1")) break;

            System.out.print("Please enter dog's breed: ");
            breed = consoleScanner.nextLine();

            System.out.print("Please enter dog's age: ");
            age = consoleScanner.nextDouble();

            // Clear out console scanner (get rid of \n)
            consoleScanner.nextLine();

            // Create a new Dog object
            // Dog newDog = new Dog(name, breed, age);
            // Add the dog to the ArrayList
            dogsList.add(new Dog(name, breed, age)); // Shortcut from
                                                     // dogsList.add(newDog);

        }
        while (!name.equalsIgnoreCase("-1"));

        // After the loop, close scanner
        consoleScanner.close();

        // Step 3) Write the dogsList to the binaryFile (ObjectOutputStream)
        try
        {
            ObjectOutputStream fileWriter = new ObjectOutputStream(new FileOutputStream(binaryFile));
            fileWriter.writeObject(dogsList);
            // After we're done writing, close the file
            fileWriter.close();
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
        }


    }

}