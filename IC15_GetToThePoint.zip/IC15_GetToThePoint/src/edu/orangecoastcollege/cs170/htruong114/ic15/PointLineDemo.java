package edu.orangecoastcollege.cs170.htruong114.ic15;

public class PointLineDemo
{

    public static void main(String[] args)
    {
        // Point has 3 constructor
        // Parameterized constructor:
        Point p1 = new Point(3, 4);
        //Copy constructor
        Point p2 = new Point(p1);
        // Change it to (5, 0)
        p2.setX(5);
        p2.setY(0);
        // Default constructor
        Point origin = new Point();

        //Print out all three points:
        System.out.println(origin + "\n" + p1 + "\n" + p2);

        //Print the distance between origin and p1
        System.out.println("Distance = " + origin.distanceTo(p1));

        //Let's make our first line:
        Line l1 = new Line (0,0,5,0);
        Line l2 = new Line (origin, p2);

        System.out.println(l1 + "\n" + l2);

        //Print the length of the lines:
        System.out.println("L1 Length = " + l1.length() );
        System.out.println("L2 Length = " + l2.length() );
        
        System.out.println(p1.equals(p2) ? "The Points are the same." : "The Points are different.");
    }

}