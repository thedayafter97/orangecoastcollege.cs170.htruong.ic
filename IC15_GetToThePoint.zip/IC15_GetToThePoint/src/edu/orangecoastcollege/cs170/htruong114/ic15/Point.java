package edu.orangecoastcollege.cs170.htruong114.ic15;

public class Point
{

    private int mX;
    private int mY;

    // Constructor (3)
    //Parameterized constructor: (regular)
    //Creates an object by initializing
    //All the fields individually
    public Point(int x, int y)
    {
        super();
        mX = x;
        mY = y;
    }

    //Copy constructor
    //Creates an object by copying the fields of existing object
    public Point(Point other)
    {
        mX = other.mX;
        mY = other.mY;
    }

    // Default constructor:
    // Creates an object by assigning
    // Default values to all fields
    public Point()
    {
        mX=0;
        mY=0;
    }

    public int getX()
    {
        return mX;
    }

    public void setX(int x)
    {
        mX = x;
    }

    public int getY()
    {
        return mY;
    }

    public void setY(int y)
    {
        mY = y;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + mX;
        result = prime * result + mY;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Point other = (Point) obj;
        if (mX != other.mX) return false;
        if (mY != other.mY) return false;
        return true;
    }

    @Override
    public String toString()
    {
        return "Point [x=" + mX + ", y=" + mY + "]";
    }

    public double distanceTo(Point otherPoint)
    {
        double distance = Math.sqrt(Math.pow((otherPoint.mX - mX),2) + Math.pow((otherPoint.mY - mY), 2));
        return distance;
    }
}