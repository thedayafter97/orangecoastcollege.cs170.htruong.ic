package edu.orangecoastcollege.cs170.htruong114.ic21;

import java.util.InputMismatchException;
import java.util.Scanner;

public class KeyboardWoes {

	public static void main(String[] args) {
		int number = 0;
		// Create a boolean variable to keep track of whether error occurred (or not)
		boolean error = false;
		Scanner consoleScanner = new Scanner(System.in);

		do {
			try {
				System.out.print("Please enter a number: ");
				number = consoleScanner.nextInt();
				System.out.print("The number you entered is " + number);
				error = false;
				// Success;
				break;
			} catch (InputMismatchException e) {
				System.out.println("Please enter only integral number.");
				error = true;
				// Clear away the String on the consoleScanner
				consoleScanner.nextLine();
				// Failure

			}
		} while (error);

		consoleScanner.close();

	}

}
