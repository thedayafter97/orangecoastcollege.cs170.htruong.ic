import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JApplet;

public class BullsEye extends JApplet
{

    public void init()
    {
        // init sets the size of your canvas;
        setSize(400, 400);
    }

    public void paint(Graphics canvas)
    {
        Graphics2D canvas2D = (Graphics2D) canvas;
        canvas2D.setStroke(new BasicStroke(10));

        RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        canvas2D.setRenderingHints(rh);

        // First oval: 350, 350, (RED)
        // Let's make a loop to draw 7 circles:
        int x = 25, y = 25, w = 350, h = 350;

        for (int i = 1; i <= 7; i++)
        {
            // Make decision to see what color
            // If circle is odd, RED
            // Else, WHITE
            if (i % 2 != 0)
                canvas.setColor(Color.RED);
            else
                canvas.setColor(Color.WHITE);

            canvas.fillOval(x, y, w, h);
            // Update the sizes:
            x += 25;
            y += 25;
            w -= 50;
            h -= 50;
        }
    }
}