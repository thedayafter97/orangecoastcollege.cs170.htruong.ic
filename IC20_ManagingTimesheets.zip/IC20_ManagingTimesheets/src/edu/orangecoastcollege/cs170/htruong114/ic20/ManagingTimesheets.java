package edu.orangecoastcollege.cs170.htruong114.ic20;

import java.text.DecimalFormat;
import java.util.Scanner;

public class ManagingTimesheets
{

    public static final int ROWS = 3;
    public static final int COLS = 5;

    public static void main(String[] args)
    {
        double[][] timesheets = new double[ROWS][COLS];
        double[] totals = new double[ROWS];
        String[] days = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" };

        Scanner consoleScanner = new Scanner(System.in);
        DecimalFormat oneDP = new DecimalFormat("0.0");

        // loop through each employee on each day
        // shortcut to "refactor" Alt + Shift + r
        for (int e = 0; e < ROWS; e++)
        {
            for (int d = 0; d < COLS; d++)
            {
                System.out.print("Please enter hours worked for employee #" + (e + 1) + " on " + days[d] + ": ");
                // Store the value in the timesheet for that employee on that
                // day
                timesheets[e][d] = consoleScanner.nextDouble();
                // Add the value to the totals for that employee
                totals[e] += timesheets[e][d];
            }
            System.out.println();

        }
        consoleScanner.close();

        for (int i = 0; i < ROWS; i++)
        {

            System.out.println("Total hours worked for employee #" + (i + 1) + ": " + oneDP.format(totals[i])
                    + "\nAverage hours worked for employee #" + (i + 1) + ": " + oneDP.format(totals[i] / 5));
            System.out.println();
        }
    }

}