package edu.orangecoastcollege.cs170.htruong114.ic20;

import java.util.Scanner;

public class TicTacToe {
	public static final int ROWS = 3;
	public static final int COLS = 3;

	public static void main(String[] args) {
		int moves = 0, row, col;

		char[][] board = new char[ROWS][COLS];

		for (int i = 0; i < ROWS; i++)
			for (int j = 0; j < COLS; j++)
				board[i][j] = '*';

		Scanner consoleScanner = new Scanner(System.in);
		System.out.println("Welcome to Tic-Tac-Toe!");
		do {
			printBoard(board);
			System.out.print("Please enter row: ");
			row = consoleScanner.nextInt() - 1;
			System.out.print("Please enter col: ");
			col = consoleScanner.nextInt() - 1;

			// Place either an 'X' or 'O' on the board
			// if moves are EVEN, put an 'X'
			// else put an 'O'
			if (moves % 2 == 0)
				board[row][col] = 'X';
			else
				board[row][col] = 'O';
			// After the move, change it!
			moves++;

		} while (!gameIsWon(board) && moves < 9); // keep playing game as long as
													// not won and move < 9
		consoleScanner.close();
		printBoard(board);
		if (moves == 9) {
			System.out.print("It's a tie!");
			System.exit(0);
		} else if (moves % 2 != 0) {
			System.out.print("Player X has won the game!");
			System.exit(0);
		} else {
			System.out.print("Player O has won the game!");
			System.exit(0);
		}
	}

	// make a method that determines whether the game is won
	public static boolean gameIsWon(char[][] anyBoard) {
		// If they are all the same and not a *
		if (anyBoard[0][0] == anyBoard[0][1] && anyBoard[0][1] == anyBoard[0][2] && anyBoard[0][0] != '*')
			return true;
		else if (anyBoard[1][0] == anyBoard[1][1] && anyBoard[1][1] == anyBoard[1][2] && anyBoard[1][0] != '*')
			return true;
		else if (anyBoard[2][0] == anyBoard[2][1] && anyBoard[2][1] == anyBoard[2][2] && anyBoard[2][0] != '*')
			return true;
		else if (anyBoard[0][0] == anyBoard[1][0] && anyBoard[1][0] == anyBoard[2][0] && anyBoard[0][0] != '*')
			return true;
		else if (anyBoard[0][1] == anyBoard[1][1] && anyBoard[1][1] == anyBoard[2][1] && anyBoard[0][1] != '*')
			return true;
		else if (anyBoard[0][2] == anyBoard[1][2] && anyBoard[1][2] == anyBoard[2][2] && anyBoard[0][2] != '*')
			return true;
		else if (anyBoard[0][0] == anyBoard[1][1] && anyBoard[1][1] == anyBoard[2][2] && anyBoard[0][0] != '*')
			return true;
		else if (anyBoard[0][2] == anyBoard[1][1] && anyBoard[1][1] == anyBoard[2][0] && anyBoard[0][2] != '*')
			return true;
		else
			return false;
	}

	// make a method that will print the board
	public static void printBoard(char[][] anyBoard) {

		for (int i = 0; i < ROWS; i++) {
			System.out.println("-------------");
			for (int j = 0; j < COLS; j++) {
				System.out.print("| " + anyBoard[i][j] + " ");
			}
			System.out.println("|");
		}
		System.out.println("-------------");
	}

}