package edu.orangecoastcollege.cs170.htruong114.ic14;

public enum PlaneType
{
       AIRBUS_320, //150 passengers
       BOEING_737 //200 passengers
}