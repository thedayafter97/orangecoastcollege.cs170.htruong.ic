package edu.orangecoastcollege.cs170.htruong114.ic14;

public class Flight
{
    private String mCarrier;
    private int mNumber;
    private double mDuration;
    private int mPassengers;
    private PlaneType mPlaneType;

    // Parameterized Constructor
    public Flight(String carrier, int number, double duration, PlaneType planeType, int passengers)
    {
        mCarrier=carrier;
        mNumber=number;
        mDuration=duration;
        mPassengers=passengers;
        mPlaneType=planeType;
    }

    // Copy Constructor (copies all number variables of existing Flight) (+1 overload)
    public Flight(Flight other)
    {
        mCarrier=other.mCarrier;
        mNumber=other.mNumber;
        mDuration=other.mDuration;
        mPassengers=other.mPassengers;
        mPlaneType=other.mPlaneType;
    }

    public String getCarrier()
    {
        return mCarrier;
    }

    public int getNumber()
    {
        return mNumber;
    }

    public double getDuration()
    {
        return mDuration;
    }

    public int getPassengers()
    {
        return mPassengers;
    }

    public PlaneType getPlaneType()
    {
        return mPlaneType;
    }

    public void setCarrier(String newCarrier)
    {
      mCarrier=newCarrier;
    }

    public void setNumber(int newNumber)
    {
        mNumber=newNumber;
    }

    public void setDuration(double newDuration)
    {
        mDuration=newDuration;
    }

    public void setPlaneType(PlaneType newPlaneType)
    {
        mPlaneType=newPlaneType;
    }

    public String toString()
    {
        String output = "Flight [Carrier=" + mCarrier + ", Number=" + mNumber + ", Duration=" + mDuration
                + ", PlaneType=" + mPlaneType + ", Passengers=" + mPassengers + "]";
        return output;
    }

    public boolean equals(Flight other)
    {
        if (mCarrier.equals(other.mCarrier) && mDuration == mDuration && mNumber == other.mNumber
            && mPassengers == other.mPassengers && mPlaneType == mPlaneType)
            return true;
        else
            return false;
    }

    // Miscellaneous methods
    public boolean addPassengers(int amount)
    {
        //Check the plane types first:
        if (mPlaneType == PlaneType.AIRBUS_320 && (mPassengers + amount) <= 150)
        {
            mPassengers += amount;
            return true;
        }
        else if (mPlaneType == PlaneType.BOEING_737 && (mPassengers + amount) <= 200)
        {
            mPassengers += amount;
            return true;
        }
        else
            return false;
    }

    public boolean removePassengers(int amount)
    {
      //Check the plane types first:
        if ((mPassengers - amount) >= 0)
        {
            mPassengers -= amount;
            return true;
        }
        else
            return false;
    }
}