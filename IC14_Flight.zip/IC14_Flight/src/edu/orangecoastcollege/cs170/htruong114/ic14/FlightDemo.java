package edu.orangecoastcollege.cs170.htruong114.ic14;

public class FlightDemo
{

    public static void main(String[] args)
    {
        Flight flight1 = new Flight("Hawaiian", 1, 5.5, PlaneType.AIRBUS_320, 100);
        Flight flight2 = new Flight(flight1);
        System.out.println(flight1);
        System.out.println(flight2);

        if (flight1.equals(flight2))
        {
            System.out.println("Both flight are the same.");
        }
        else
            System.out.println("The flights are different.");
        System.out.println();

        flight2.setCarrier("Delta");
        flight2.setNumber(1284);
        flight2.setDuration(6.0);
        flight2.setPlaneType(PlaneType.BOEING_737);

        System.out.println(flight1);
        System.out.println(flight2);

        if (flight1.equals(flight2))
        {
            System.out.println("Both flight are the same.");
        }
        else
            System.out.println("The flights are different.");
        System.out.println();
        System.out.println("~~~~~Adding 100 Passengers to both Flights~~~~~");

        flight1.addPassengers(100);
        flight2.addPassengers(100);

        System.out.println(flight1);
        System.out.println(flight2);

        System.out.println();
        System.out.println("~~~~~Removing 200 Passengers from both Flights~~~~~");

        flight1.removePassengers(200);
        flight2.removePassengers(200);

        System.out.println(flight1);
        System.out.println(flight2);
    }

}