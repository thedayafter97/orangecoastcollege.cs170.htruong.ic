import java.text.DecimalFormat;
import java.util.Scanner;

public class GradingApp
{

    public static void main(String[] args)
    {
        double grade, low = Double.MAX_VALUE, average, high = Double.MIN_VALUE, sum = 0;
        int count = 0, numberAs = 0, numberBs = 0, numberCs = 0, numberDs = 0, numberFs = 0;
        Scanner consoleScanner = new Scanner(System.in);
        DecimalFormat noDPs = new DecimalFormat("0");
        DecimalFormat oneDP = new DecimalFormat("0.#");

        System.out.println("Please input grades one per line (or type -1 to quit):");
        do
        {
            // Code to repeat
            grade = consoleScanner.nextDouble();

            // to automatically format code (indent): Ctrl + Shift + F
            // Check to see if the grade != -1
            if (grade != -1)
            {
                // Add 1 to the count
                count++;

                // Add grade to the sum
                sum += grade;

                // Determine what letter grade
                if (grade >= 90)
                    numberAs++;
                else if (grade >= 80)
                    numberBs++;
                else if (grade >= 70)
                    numberCs++;
                else if (grade >= 60)
                    numberDs++;
                else
                    numberFs++;

                // Let's check to see if the grade is the new low
                if (grade < low) low = grade;
                if (grade > high) high = grade;
            }
        }
        while (grade != -1);
        consoleScanner.close();

        //Caculate the average
        average = sum / count;

        System.out.println("\nTotal number of grades = " + count + "\n"
                            + "Number of A's = " + numberAs + "\n"
                            + "Number of B's = " + numberBs + "\n"
                            + "Number of C's = " + numberCs + "\n"
                            + "Number of D's = " + numberDs + "\n"
                            + "Number of F's = " + numberFs + "\n"
                            + "Low Grade = " + noDPs.format(low) + "%\n"
                            + "Class Average = " + oneDP.format(average) + "%\n"
                            + "High Grade = " + noDPs.format(high) + "%");
    }
}