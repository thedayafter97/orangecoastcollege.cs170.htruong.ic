package edu.orangecoastcollege.cs170.htruong114.ic22;

import java.util.InputMismatchException;
import java.util.Scanner;

public class AppointmentSchedulerDemo 
{

	public static void main(String[] args) throws TimeInUseException, InvalidTimeException 
	{
		int time = 0;
		boolean error = false;
		
		String[] names = new String[6];
		
		for (int i = 0; i < names.length; i++) 
		{
			names[i] = "";
		}
		
		Scanner consoleScanner = new Scanner(System.in);

		do {
			try {
				error = false;
				System.out.print("What time would like to schedule: ");
				time = consoleScanner.nextInt() - 1;
				
				if (time < 0 || time > 6)
					throw new InvalidTimeException();
				
				System.out.print("Please enter your name: ");
				consoleScanner.nextLine();
				String inputName = consoleScanner.nextLine();
				
				if (names[time].equalsIgnoreCase(""))
					names[time] = inputName;
				else 
					throw new TimeInUseException();
				
			} 
			catch (InputMismatchException e) 
			{
				System.out.println("Please enter a valid number, Not CHARCTERS!!!");
				error = true;
				consoleScanner.nextLine();
			} 
			catch (TimeInUseException e) 
			{
				System.out.println(e.getMessage());
				error = true;
			} 
			catch (InvalidTimeException e) 
			{
				System.out.println(e.getMessage());
				error = true;
			}
			
			if (!error) 
			{
				System.out.print("Would you like to schedule another? (Y for yes or N for no): ");
				String another = consoleScanner.next();
				if (another.equalsIgnoreCase("Y")) 
				{
					error = true;
				}
			}
		} while (error);
		consoleScanner.close();
		
		System.out.println("\n~Appointment Scheduler~");
		int hour = 0;		
		for (String name : names) 
		{
			hour++;
			System.out.println("Hour " + hour + "pm: " + name);
		}
		
	}
}