package edu.orangecoastcollege.cs170.htruong114.ic22;

public class InvalidTimeException extends Exception 
{

	public InvalidTimeException() 
	{
		super("Please enter a valid time! 1-6");
	}

	public InvalidTimeException(String message) 
	{
		super(message);

	}

	
}
