package edu.orangecoastcollege.cs170.htruong114.ic22;

public class TimeInUseException extends Exception 
{

	public TimeInUseException() 
	{
		super("It was taken!!!");

	}

	public TimeInUseException(String message) 
	{
		super(message);

	}

}
