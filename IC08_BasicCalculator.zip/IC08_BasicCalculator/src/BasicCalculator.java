import java.text.DecimalFormat;
import java.util.Scanner;

public class BasicCalculator 
{

	public static void main(String[] args) 
	{
		int stars = 71;
		double number1, number2, total;
		String input;
		Scanner consoleScanner = new Scanner(System.in);
		DecimalFormat noDPs = new DecimalFormat("0");
		DecimalFormat oneDP = new DecimalFormat("0.0");
		
		for (int i = 0; i < stars; i++) 
		{
            if (i == 0 || i == 4) 
            {
                for (int j = 0; j < stars; j++) 
                {System.out.print("*");}
                System.out.println();   
            }
            if (i == 1 || i == 3) 
            {
                for (int j = 0; j < stars; j++) 
                {
                    if (j == 0 || j == 68) 
                    {System.out.print("**");}
                    else if (j >= 1 && j <= 67 )
                    {System.out.print(" ");}
                }
                System.out.println();
            }
            if (i == 2)
            {
            	for (int j = 0; j < stars; j++) 
                {
                    if (j == 0 || j == 68) 
                    {System.out.print("**");}
                    else if (j == 18)
                    {System.out.print("WELCOME TO HOA'S BASIC CALCULATOR");}
                    else if (j >= 1 && j <= 35)
                    {System.out.print(" ");}    
                }
                System.out.println();
            }
            
		}
		System.out.println("Type one of the following operators:\n"
							+ " +   (for adding numbers)\n"
							+ " -   (for subtracting numbers)\n"
							+ " *   (for multiplying numbers)\n"
							+ " /   (for dividing numbers)\n"
							+ " %   (for finding the remainder when two numbers are devided)\n"
							+ " ^   (for exponentiation - one number raised to the power of the other)");
		for (int i = 0; i < stars; i++)
		{System.out.print("*");}
		System.out.println();
		
		input = consoleScanner.next();
		
		if (input.equals("+"));
		
		else if (input.equals("-"));
		
		else if (input.equals("*"));
		
		else if (input.equals("/"));
		
		else if (input.equals("%"));
		
		else if (input.equals("^"));

		else 
		{
			System.err.print("Please type one of the following operators");
			System.exit(0);
		}
		
		System.out.print("Enter an operand (number): ");
		number1 = consoleScanner.nextDouble();
		System.out.print("Enter an operand (number): ");
		number2 = consoleScanner.nextDouble();
		consoleScanner.close();
		
		switch (input)
		{
			case "+":
			{
				total = number1 + number2;
				System.out.println(noDPs.format(number1) + " + " + noDPs.format(number2) + " = " + oneDP.format(total));
				break;
			}
			case "-":
			{
				total = number1 - number2;
				System.out.println(noDPs.format(number1) + " - " + noDPs.format(number2) + " = " + oneDP.format(total));
				break;
			}
			case "*":
			{
				total = number1 * number2;
				System.out.println(noDPs.format(number1) + " * " + noDPs.format(number2) + " = " + oneDP.format(total));
				break;
			}
			case "/":
			{
				total = number1 / number2;
				System.out.println(noDPs.format(number1) + " / " + noDPs.format(number2) + " = " + oneDP.format(total));
				break;
			}
			case "%":
			{
				total = number1 % number2;
				System.out.println(noDPs.format(number1) + " % " + noDPs.format(number2) + " = " + oneDP.format(total));
				break;
			}
			case "^":
			{	
				total = Math.pow(number1, number2);
				System.out.println(noDPs.format(number1) + " ^ " + noDPs.format(number2) + " = " + oneDP.format(total));
				break;
			}	
		}	
	}
}