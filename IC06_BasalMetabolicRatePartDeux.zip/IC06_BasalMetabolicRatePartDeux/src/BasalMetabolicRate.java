import java.text.DecimalFormat;
import java.util.Scanner;
public class BasalMetabolicRate
{

    public static void main(String[] args)
    {
        int activity;
        double weight, height, bmr, age, bars;
        String gender;
        
        Scanner consoleScanner = new Scanner(System.in);
        
        DecimalFormat noDPs = new DecimalFormat("0");
        DecimalFormat oneDP = new DecimalFormat("0.0");
        
        System.out.print("Please enter your weight (lb): ");
        weight = consoleScanner.nextDouble();
        
        System.out.print("Please enter your height (in): ");
        height = consoleScanner.nextDouble();
        
        System.out.print("Please enter your age: ");
        age = consoleScanner.nextDouble();
        
        System.out.println("Please enter Male or Female: ");
        gender = consoleScanner.next().toUpperCase(); // female = > FEMALE
        
        if (gender.startsWith("F"))
            bmr = 655 + (4.35 * weight) + (4.7 * height) - (4.7 * age);
        else
            bmr = 66 + (6.23 * weight) + (12.7 * height) - (6.8 * age);
         
        System.out.println("Please enter the number corresponding with your activity factor:\n"
                         + "1. Sedentary (not active)\n"
                         + "2. Somewhat active (exercise occasionally)\n"
                         + "3. Active (exercise 3-4 times per week)\n"
                         + "4. Highly Active (exercise every day)");
        activity = consoleScanner.nextInt();
        
        consoleScanner.close();
        
        if (activity == 1) //Sedentary, increase bmr by 20%
            bmr *= 1.2; // 1.2 = 1 + 0.2
        else if (activity == 2)
            bmr *= 1.3;
        else if (activity == 3)
            bmr *= 1.4;
        else
            bmr *= 1.5;
        
        bars = bmr / 230; //CHOCOLATE_BAR_CALORIES = 230   
        System.out.println("As a " + gender + " your BMR x Activity Factor is " + noDPs.format(bmr) 
                            + " and you need to eat " 
                            + oneDP.format(bars) 
                            + " chocoloate bars to maintain this amount of calories.");  
    }

}
